SLEEP=30
EXIT=0
if [ $# -gt 0 ]; then
	SLEEP=$1
fi
if [ $# -gt 1 ]; then
	EXIT=$2
fi
sleep $SLEEP
echo "sleep exit $EXIT after $SLEEP sec"
exit $EXIT
