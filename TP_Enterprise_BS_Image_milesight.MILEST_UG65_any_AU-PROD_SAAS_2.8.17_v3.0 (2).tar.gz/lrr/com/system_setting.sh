# IMPORTANT:
# - no assumption about used shell: as portable as possible
# - use only shell syntax and basic command with options limited to what is widely supported

#
# binary and scripts need information about the gateway to work correctly
# - LRR software root directory (ROOTACT)
# - location of various system binaries and files
# - information about software (firmware type, firmware version, support commands and their options)
#   or hardware (support of Wifi, and other)
#
# These information are contained into
# - ROOTACT: determine at boot and copied into a file located in /var/run (present on all Linux-based system)
# - configuration files part of the LRR delivery:
#   . general system configuration created by "menuconfig" or manually and used also for building LRR
#   . model specific configuration created automatically and/or manually, mostly describing actual characteristics
#
# All shells scripts will then include the whole configuration to adapt their behaviour to the running gateway
#
# to manage upward compatibility (new configuration mechanism not yet ported on all gateways)
# - a minimal "general system configuration" will be dynamically created and reused at each boot
#

LRR_SYSTEM_INIT=/var/run/lrrsystem

# file for logs (only console if empty)
# set ACTLOG with the full path of the log file

actSyslog() {
    LOGGER=`which logger`
    if [ -x $LOGGER ]; then
        logger "$1"
    fi
}

actDebug() {
    VOLATILE_DEBUG=/var/run/lrrdebug
    PERSISTENT_DEBUG=/etc/lrrdebug
    # either volatile debug (removed when rebooting) or persistent debug (to be removed manually)
    if [ -f  $VOLATILE_DEBUG -o -f $PERSISTENT_DEBUG ]; then
        actSyslog "LRR: $1"
    fi
}

actInitLog() {

    if [ ! -z "$ACTLOG" ]; then
        if [ ! -f "$ACTLOG" ]; then
            t=`date +%c`
            echo "Created on $t" > $ACTLOG
        fi
    fi
}

actLog() {
    msg="[$0] $1"
    actDebug "$msg"
    t=`date +%c`
    msg="$t $msg"
    echo "$msg"
    if [ ! -z "$ACTLOG" ]; then
       echo "$msg" >> $ACTLOG
    fi
}

actLogInfo() {
    actLog "Info: $1"
}

actLogWarning() {
    actLog "Warning: $1"
}

actLogFatal() {
    actLog "FATAL: $1"
    actSyslog "LRR FATAL $1"
    exit 1
}

setRootAct() {
    if [ ! -f $LRR_SYSTEM_INIT ]; then
        # just in case the original script and not the updated boot service is executed
        if [ "$ROOTACT" = "_REPLACEWITHROOTACT_" ]; then
            return
        fi
        msg="create $LRR_SYSTEM_INIT: ROOTACT=$ROOTACT"
        actLogInfo "$msg"
        echo "export ROOTACT=$ROOTACT" > $LRR_SYSTEM_INIT
        chmod a+x $LRR_SYSTEM_INIT
    fi
}

#
# once installed, called by all scripts to "load" gateway characteristics
# EXIT if not possible: should happen only during development phase, not when the porting is complete
#

initSystemSetting() {

    if [ -z "$ROOTACT" ]; then
        if [ ! -f "$LRR_SYSTEM_INIT" ]; then
            actLogFatal "$LRR_SYSTEM_INIT not present"
        else
            source $LRR_SYSTEM_INIT
        fi
    fi

    if [ ! -d $ROOTACT ]; then
        actLogFatal "ROOTACT ($ROOTACT) not a directory"
    fi

    # export all definitions
    set -a

    # after installation, parameters script should contain system name
    LRR_PARAMETERS="$ROOTACT/usr/etc/lrr/_parameters.sh"
    if [ -f $LRR_PARAMETERS ]; then
        . $LRR_PARAMETERS
    fi

    # then call the script defining other gateways characteristics
    SYSTEM_DEF=$ROOTACT/lrr/system/system_definition.sh
    SYSTEM_CHAR=$ROOTACT/lrr/system/system_characteristics.sh
    SUPLOG_DEF=$ROOTACT/lrr/system/suplog_definition.sh
    LRR_SETTING=$ROOTACT/lrr/system/lrr_setting.sh

    if [ -f $SYSTEM_DEF ]; then
        . $SYSTEM_DEF
        export SYSTEM_DEF=y
    fi

    if [ -f $SYSTEM_CHAR ]; then
        . $SYSTEM_CHAR
    fi

    if [ -f $LRR_SETTING ]; then
        . $LRR_SETTING
    fi

    if [ -f $SUPLOG_DEF ]; then
        . $SUPLOG_DEF
    fi

    if [ -z "$SYSTEM" ]; then
        actLogFatal "SYSTEM not defined"
    fi

    if [ "$DYNAMIC_HAL" = "y" ] && [ ! -z "$DYNAMIC_HAL_PATH" ]; then
        export LD_LIBRARY_PATH="$DYNAMIC_HAL_PATH:$LD_LIBRARY_PATH"
    fi

    if [ "$SYSTEM" = "ciscoms" ]; then
        umask 0002
    fi

    export SYSTEM_DEF=y
}


# boot services getting hard-coded ROOTACT definition (set by substituting REPLACEWITHROOTACT)
# must called the script with "setrootact" as 1st argument to force /var/lrr/lrrsystem to be created if missing
# other scripts will just source the script to get all definition imported

actInitLog

if [ "$1" = "setrootact" ]; then
    setRootAct
fi

initSystemSetting
