#!/bin/sh

export PATH=$PATH:$ROOTACT/lrr/com/

#This will call the get_hal_version.x binary and format the returned version

if [ ! -f $ROOTACT/lrr/com/get_hal_version.x ]; then
	echo "get_hal_version.x not found, cannot read HAL version"
	exit 1
fi

#run FPGA binary
get_hal_version.x | sed 's/Version: //' | sed 's/\;//'

exit 0
