#!/bin/sh

VPNCFG="$ROOTACT/usr/etc/lrr/vpn.cfg"
OLDVPNCFG=""
LRRINI="$ROOTACT/usr/etc/lrr/lrr.ini"
DEFLRRINI="$ROOTACT/lrr/config/lrr.ini"
IPF2INI="$ROOTACT/usr/etc/lrr/ipfailover2.ini"
DEFIPF2INI="$ROOTACT/lrr/config/ipfailover2.ini"
MICMDOPTIONS="-e"
MICMD="$ROOTACT/lrr/moreini/moreini.x $MICMDOPTIONS"
TMPFILE="/tmp/_migrate$$"
CHECKVPN2SH="$ROOTACT/lrr/ipsecmgr/checkvpn2.sh"
FORLRRINI=""

if [ -f /var/run/lrrsystem ]; then
    . /var/run/lrrsystem
fi

if    [ -z "$ROOTACT" ]
then
    if    [ -d /mnt/fsuser-1/actility ]
    then
        export ROOTACT=/mnt/fsuser-1/actility
    else
        case $(uname -n) in
            klk-lpbs*)
                export ROOTACT=/user/actility
                ;;
            klk-wifc*)
                export ROOTACT=/user/actility
                ;;
            *)
                export ROOTACT=/home/actility
                ;;
        esac
    fi
fi

setting=$ROOTACT/lrr/com/system_setting.sh
if [ -f $setting ]; then
    . $setting
else
    if [ -f $ROOTACT/lrr/base/TARGET ]; then
        # define SYSTEM
        . $ROOTACT/lrr/base/TARGET
    fi
fi

[ -f $ROOTACT/lrr/com/_parameters.sh ] && . $ROOTACT/lrr/com/_parameters.sh
[ -f $ROOTACT/lrr/com/_functions.sh ] && . $ROOTACT/lrr/com/_functions.sh

. $ROOTACT/lrr/com/system_api.sh

SystemGetFilePath "$ROOTACT/lrr/postinstall" "custom_migrate2nfr920.sh"
custom_migration="${sysfilepath}"
if [ -f "$custom_migration" ]; then
    echo "$LINENO - found custom migration2nfr920 script: $custom_migration"
    . $custom_migration
fi

checkMigrationMode()
{
    # 0 : no migration (done)
    # 1 : no migration (blocked)
    # 2 : migrate checkvpn2/ipfailover2
    # 3 : migrate ipfailover2 only (checkvpn2 already migrated)
    # 4 : migrate checkvpn2 only (ipfailover2 already migrated)
    if [ -z "$OLDVPNCFG" ]
    then
        vpnfile=$(getIniConf $LRRINI suplog networkconfigvpnfile)
        [ -z "$vpnfile" ] && vpnfile=$(getGlobalIniConf suplog networkconfigvpnfile)
    else
        vpnfile="$OLDVPNCFG"
    fi
    if [ -f "$vpnfile" ] && [ ! -f "$VPNCFG" ]
    then
        convVpn=1
    else
        if [ -f "$VPNCFG" ]; then
            echo "$LINENO - checkvpn2: New vpn.cfg already exists, no conversion to be done..."
        else
            echo "$LINENO - checkvpn2: Can't find vpn.cfg to migrate, no conversion to be done..."
        fi
        convVpn=0
    fi

    if [ -f "$IPF2INI" ] && grep principal $IPF2INI # Fix for invalid ipfailover2.ini in place before migration
    then
        echo "$LINENO - ipfailover2: ipfailover2.ini already exists, no conversion to be done..."
        convIpsec=0
    else
        rm -f $IPF2INI
        convIpsec=1
    fi

    novpnmigration=$(getGlobalIniConf services novpnmigration)
    nofailovermigration=$(getGlobalIniConf services nofailovermigration)
    noservicemigration=$(getGlobalIniConf services noservicemigration)

    [ -z "$novpnmigration" ]      || { [ "$novpnmigration" -eq 1 ] && convVpn=0 ; }
    [ -z "$nofailovermigration" ] || { [ "$nofailovermigration" -eq 1 ] && convIpsec=0 ; }
    [ -z "$noservicemigration" ]  || { [ "$noservicemigration" -eq 1 ] && convVpn=0 && convIpsec=0 ; }

    [ $convVpn -eq 0 ] && [ $convIpsec -eq 0 ] && return 0
    [ $convVpn -eq 1 ] && [ $convIpsec -eq 1 ] && return 2
    [ $convVpn -eq 0 ] && [ $convIpsec -eq 1 ] && return 3
    [ $convVpn -eq 1 ] && [ $convIpsec -eq 0 ] && return 4
}

checkMigrationNfr920()
{
    isNFR920MigrationRequested "$LRRINI"
    # isNFR920MigrationRequested returns 1 if migration requested, 0 otherwise
    [ $? -eq 0 ] && return 1
    # Ok to migrate
    return 0
}

ready2migrateNfr920()
{
    vpn1status=$(getIniConf $LRRINI services checkvpn)
    # Can't enable NFR920 with old checkvpn
    [ ! -z "$vpn1status" ] && [ "$vpn1status" -eq 1 ] && echo "$LINENO - nfr920: checkvpn active, can not enable NFR920" && return 1
    # ipfailover2 required for NFR920, therefore check for service configuration
    [ ! -f "$IPF2INI" ] && echo "$LINENO - nfr920: ipfailover2.ini missing, can not enable NFR920" && return 1
    return 0
}

# Convertion from old vpn.cfg to new one
# Actually the 'conversion' is just a copy in $ROOTACT/usr/etc/lrr
convertVpnCfg()
{
    cp "$vpnfile" "$VPNCFG"
    if [ $? = "0" ]
    then
        rm -f "$vpnfile"
        echo "$LINENO - checkvpn2: vpn.cfg successfully moved to $(dirname $VPNCFG)"
        return 0
    else
        echo "$LINENO - checkvpn2: failed to convert vpn.cfg !"
        return 1
    fi
}

cleanOldCheckVpn()
{
    # need to know where are the service files on this system
    getServicePrefix
    service2clean="${SERVICEPREFIX}checkvpn"
    [ ! -f "$service2clean" ] && [ "$SYSTEM" = "wirmaar" ] && service2clean="/user/rootfs_rw/etc/rcU.d/S91checkvpn"
    if [ -f "$service2clean" ]; then
        $service2clean stop >/dev/null 2>&1
        pid=$(ps | grep checkvpn[^2] | grep respawn | awk '{ print$1 }')
        [ ! -z "$pid" ] && kill $pid >/dev/null 2>&1
        pid=$(ps | grep checkvpn.sh | awk '{ print$1 }')
        [ ! -z "$pid" ] && kill $pid >/dev/null 2>&1
        mv $service2clean $ROOTACT/checkvpnservice.$(date +%y%m%d-%H%M%S)
        # Some GW (Ufispace) have an alternate checkvpn script
        rm -f ${SERVICEPREFIX}checkvpn.*
	rm -f /etc/rc?.d/S??checkvpn 2> /dev/null
        echo "$LINENO - checkvpn cleansing: old checkvpn removed"
    else
        echo "$LINENO - checkvpn cleansing: nothing done for old checkvpn script"
    fi
    # Gemtek has a preloaded ipsec service
    if [ -f "${SERVICEPREFIX}ipsec" ]
    then
        ${SERVICEPREFIX}ipsec stop >/dev/null 2>&1
        mv ${SERVICEPREFIX}ipsec $ROOTACT/ipsecservice.$(date +%y%m%d-%H%M%S)
        echo "$LINENO - checkvpn cleansing: native ipsec removed"
    fi
}

# select constraint number depending on checkfreq and interface type
# use: constraintnum=$(selectConstraint <checkfreq> <intertype>)
selectConstraint()
{
    freq=$1
    typ=$2

    [ -z "$freq" ] && freq=0
    [ -z "$typ" ] && typ="principal"
    if [ "$typ" = "principal" ]
    then
        if [ $freq -le 10 ]
        then
            echo "0"
        elif [ $freq -le 60 ]
        then
            echo "1"
        else
            echo "2"
        fi
    else
        if [ $freq -le 30 ]
        then
            echo "0"
        elif [ $freq -le 180 ]
        then
            echo "1"
        else
            echo "2"
        fi
    fi
}

selectDefaultConstraint()
{
    itf=$1
    case $itf in
        eth*|en*|wl*)
            echo "0"
            ;;
        ppp*|ww*|cellular*)
            echo "1"
            ;;
        *)
            echo ""
            ;;
    esac
}

selectInterfaceType()
{
    itf=$1
    case $itf in
        eth*|en*)
            echo "0"
            ;;
        ppp*|ww*|wl*|cellular*)
            echo "1"
            ;;
        *)
            echo "0"
            ;;
    esac
}

# generate ipfailover.ini from lrr.ini, lrr.x was in charge of the ipfailover previously
convertIpfailover()
{
    echo "$LINENO - ipfailover2: ipfailover conversion starting."

    conffile="$IPF2INI"
    if [ -f "$conffile" ]
    then
        echo "$LINENO - ipfailover2: ipfailover2.ini already exists, no conversion to be done..."
        return 1
    fi

    # If ifacefailover already enabled, configure failover2 based on ifacefailover
    # otherwise setup single interface mode with current primary and default parameters
    isfoena=$(getIniConf $LRRINI "ifacefailover" "enable")
    [ -z "$isfoena" ] && isfoena=0

    if [ "$isfoena" -eq 1 ]; then
        # get parameters configured in [ipfailover2]
        prin=$(getGlobalIniConf ifacefailover principal)
        routes=$(getGlobalIniConf ifacefailover routes)
        rescue=$(getGlobalIniConf ifacefailover rescue)
        rescueroutes=$(getGlobalIniConf ifacefailover rescueroutes)
        intervaddrt=$(getGlobalIniConf ifacefailover intervaddrt)
        countaddrt=$(getGlobalIniConf ifacefailover countaddrt)
        rescuesvp=$(getGlobalIniConf ifacefailover rescuesvp)
        # If failover is disable, rescue shall have no value
        [ $rescuesvp -ne 1 ] && rescue=""

        # ignore all parameters that is now configured in [bandwidthconstraint_<type>:<x>] excepted
        # checkfreq to select the bandwidthconstraint number
        checkfreq=$(getGlobalIniConf ifacefailover checkfreq)
        pconstraint=$(selectConstraint "$checkfreq" principal)
        rescuecheckfreq=$(getGlobalIniConf ifacefailover rescuecheckfreq)
        rconstraint=$(selectConstraint "$rescuecheckfreq" rescue)
    else
        if [ ! -f "$custom_migration" ]; then
            echo "$LINENO - ipfailover2: no custom script for $SYSTEM, can not find default principal/rescue interfaces..."
            return 1
        fi
        # ipfailover was not configured
        # Setup ipfailover2 according to current network configuration
        prin=$(getFailoverPrincipalInterface)
        rescue=$(getFailoverRescueInterface)
        pconstraint=$(selectDefaultConstraint "$prin")
        rconstraint=$(selectDefaultConstraint "$rescue")
        # PT-1601: do not enable rescuesvp if ipfailover=0.
        rescuesvp=0

        # Use default routes as routes
        routes=""
        rescueroutes=""
    fi
    echo "$LINENO - ipfailover2: principal interface is '$prin'"

    # Set default value if not set
    [ -z "$prin" ] &&         prin="eth0"
    [ -z "$routes" ] &&       routes="8.8.8.8 8.8.4.4"
    [ -z "$rescuesvp" ] &&    rescuesvp="0"
    [ -z "$rescue" ] &&       rescue=""
    [ -z "$rescueroutes" ] && rescueroutes=""
    [ -z "$countaddrt" ] &&   countaddrt="5"
    [ -z "$intervaddrt" ] &&  intervaddrt="1"
    [ -z "$removessh" ] &&    removessh="0"
    [ -z "$constraint" ] &&   constraint="0"
    [ -z "$rconstraint" ] &&  rconstraint="1"

    touch "$conffile"

    # Set parameters in ipfailover2.ini
    # As long as we are not sure if NFR920 is activated or not, used configured routes
    # It will be set to LRC/SLRC later on NFR920 migration
    {
        echo "[ipfailover2]"
        echo "    principal=$prin"
        echo "    routes=$routes"
        echo "    rescuesvp=$rescuesvp"
        echo "    rescue=$rescue"
        echo "    rescueroutes=$rescueroutes"
        echo "    countaddrt=$countaddrt"
        echo "    intervaddrt=$intervaddrt"
        echo "    removessh=$removessh"
        echo "    bandwidthconstraint_principal=$constraint"
        echo "    bandwidthconstraint_rescue=$rconstraint"
    } > $TMPFILE

    $MICMD -t "$conffile" -y -a "$TMPFILE"
    if [ "$?" = "0" ]
    then
        echo "$LINENO - ipfailover2: configured"
    else
        echo "$LINENO - ipfailover2: failed to configure"
    fi

    if ip rule > /dev/null 2>&1; then
        pingaddrsrc="@itf"
    else
        pingaddrsrc=""
    fi

    ptype=$(selectInterfaceType "$prin")
    rtype=$(selectInterfaceType "$rescue")

    # Set ping addresses in lrr.ini
    {
        echo "[netitf:0]"
        echo "    pingaddrsrc=$pingaddrsrc"
        echo "[netitf:1]"
        echo "    pingaddrsrc=$pingaddrsrc"
        echo
        echo "[$SYSTEM/netitf:0]"
        echo "    enable=1"
        echo "    name=$prin"
        echo "    type=$ptype"
        echo
        echo "[$SYSTEM/netitf:1]"
        echo "    enable=$rescuesvp"
        echo "    name=$rescue"
        echo "    type=$rtype"
    } > $TMPFILE

    FORLRRINI="$(cat $TMPFILE)"
    rm -f $TMPFILE

    return 0
}


# update gpfailover routes according to NFR920 (either SLRCs or LRCs according to checkvpn activation status)
updateIpfailover()
{
    echo "$LINENO - ipfailover2: routes update for NFR920 starting"

    conffile="$IPF2INI"
    if [ ! -f "$conffile" ]
    then
        echo "$LINENO - ipfailover2: ipfailover2.ini missing. Can not be updated ..."
        return 1
    fi

    # if IPSECCONF defined here we are in test mode => the file may be absent, in this
    # case just set IPSECCONF to empty
    [ ! -z "$IPSECCONF" -a ! -f "$IPSECCONF" ] && IPSECCONF=""

    # if checkvpn present ipsec is activated.
    # if IPSECCONF set that means it's a validation test => do not check checkvpn service
    if [ ! -z "$IPSECCONF" -o -f "${SERVICEPREFIX}checkvpn2" ]
    then
        # when ipsec is activated SLRC addresses must be used
        [ -f $ROOTACT/lrr/ipsecmgr/checkvpn2.conf ] && . $ROOTACT/lrr/ipsecmgr/checkvpn2.conf
        [ -z "$IPSECCONF" ] && cvLoadConf 1
        lrc1=$(cat $IPSECCONF | sed 's/#.*//' | sed -n "/^conn lrc1/,/^[^ \t]/p" | awk "/^[ \t]*right[ \t]*=/" | sed "s/.*=//")
        nblrc=$(getIniConf $LRRINI lrr nblrc)
        if [ -z "$nblrc" -o "$nblrc" = "2" ]
        then
            lrc2=$(cat $IPSECCONF | sed 's/#.*//' | sed -n "/^conn lrc2/,/^[^ \t]/p" | awk "/^[ \t]*right[ \t]*=/" | sed "s/.*=//")
        else
            lrc2=""
        fi
    else
        lrc1=$(getIniConf $LRRINI "laplrc:0" addr)
        nblrc=$(getIniConf $LRRINI lrr nblrc)
        if [ -z "$nblrc" -o "$nblrc" = "2" ]
        then
            lrc2=$(getIniConf $LRRINI "laplrc:1" addr)
        else
            lrc2=""
        fi
    fi

    lrclst=""
    [ ! -z "$lrc1" ] && [ ! -z "$lrc2" ] && lrclst="\"$lrc1 $lrc2\""
    [ ! -z "$lrc1" ] && [   -z "$lrc2" ] && lrclst="\"$lrc1\""
    [   -z "$lrc1" ] && [ ! -z "$lrc2" ] && lrclst="\"$lrc2\""

    if [ ! -z  "$lrclst" ]; then
        # Set parameters in ipfailover2.ini
        {
            echo "[ipfailover2]"
            echo "    routes=$lrclst"
        } > $TMPFILE

        $MICMD -t "$conffile" -y -a "$TMPFILE"
        if [ "$?" = "0" ]
        then
            echo "$LINENO - ipfailover2: routes updated for NFR920"
            return 0
        else
            echo "$LINENO - ipfailover2: fail to update routes for NFR920"
            return 1
        fi
    else
        echo "$LINENO - ipfailover2: no lrc address found. Keeping default routes for NFR920"
    fi

    return 0
}

cleanOldIpfailover()
{
    echo "$LINENO - ipfailover cleansing: nothing to clean..."
}

# ALL THESE OPTIONS ARE ONLY FOR TESTING MODE !
while [ $# -gt 1 ]
do
    case $1 in
        --vpncfg)
            shift
            VPNCFG="$1"
            shift
            ;;
        --oldvpncfg)
            shift
            OLDVPNCFG="$1"
            shift
            ;;
        --lrrini)
            shift
            LRRINI="$1"
            shift
            ;;
        --ipf2ini)
            shift
            IPF2INI="$1"
            shift
            ;;
        --moreini)
            shift
            MICMD="$1 $MICMDOPTIONS"
            shift
            ;;
        --ipsecconf)
            shift
            IPSECCONF="$1"
            shift
            ;;
        *)    break
            ;;
    esac
done
#echo "VPNCFG=$VPNCFG"
#echo "LRRINI=$LRRINI"
#echo "DEFLRRINI=$DEFLRRINI"
#echo "IPF2INI=$IPF2INI"
#echo "DEFIPF2INI=$DEFIPF2INI"
#exit

if [ ! -f "$LRRINI" ]
then
    echo "$LINENO - lrr.ini not found, the environment is not correct. Aborted."
    exit 1
fi

checkMigrationMode
mode=$?

migrateCheckvpn=0
migrateFailover=0

case $mode in
    0)
        migrateCheckvpn=0
        migrateFailover=0
        ;;
    1)
        migrateCheckvpn=0
        migrateFailover=0
        ;;
    2)
        migrateCheckvpn=1
        migrateFailover=1
        ;;
    3)
        migrateCheckvpn=0
        migrateFailover=1
        ;;
    4)
        migrateCheckvpn=1
        migrateFailover=0
        ;;
esac

# Postpone migration as long as custom config is not available
if [ ! -f $ROOTACT/usr/etc/lrr/lrr.ini ]; then
        migrateCheckvpn=0
        migrateFailover=0
fi

[ "$migrateCheckvpn" -eq 1 ] && echo "$LINENO - Migration from checkvpn to checkvpn2 planned ..."
[ "$migrateFailover" -eq 1 ] && echo "$LINENO - Migration from ipfailover to ipfailover2 planned ..."

getServicePrefix

if [ $migrateCheckvpn -eq 1 ]; then
    # Convert vpn.cfg
    if [ -f "$VPNCFG" ]
    then
        echo "$LINENO - checkvpn2: New vpn.cfg already exists, no conversion to be done..."
    else
        convertVpnCfg && stopOldCheckVpn="1"
    fi
fi

if [ $migrateFailover -eq 1 ]; then
    if [ -f "$IPF2INI" ]
    then
        echo "$LINENO - ipfailover2: ipfailover2.ini already exists, no conversion to be done..."
    else
        convertIpfailover && stopOldIpfailover="1"
    fi
fi

# Stop old checkvpn if conversion has been done
[ -f "$VPNCFG" ] && cleanOldCheckVpn
# Stop old ipfailover if conversion has been done
[ -f "$IPF2INI" ] && cleanOldIpfailover

isfoena=$(getIniConf $LRRINI "ifacefailover" "enable")
[ -z "$isfoena" ] && isfoena=0

# Activate NFR920, disable migration, force ipfailover service
{
    echo "$FORLRRINI"
    echo "[services]"
    # active checkvpn only if the vpn.cfg has been converted
    [ ! -z "$stopOldCheckVpn" ]   && [ "$stopOldCheckVpn" -eq 1 ]   && echo "    checkvpn2=1"
    [ ! -z "$stopOldCheckVpn" ]   && [ "$stopOldCheckVpn" -eq 1 ]   && echo "    checkvpn=__TOBEREMOVED__"
    [ ! -z "$stopOldIpfailover" ] && [ "$stopOldIpfailover" -eq 1 ] && echo "    ipfailover2=1"
    [ ! -z "$stopOldIpfailover" ] && [ "$stopOldIpfailover" -eq 1 ] && echo "    ipfailover=__TOBEREMOVED__"
    [ ! -z "$stopOldIpfailover" ] && [ "$stopOldIpfailover" -eq 1 ] && echo "[ifacefailover]"
    [ ! -z "$stopOldIpfailover" ] && [ "$stopOldIpfailover" -eq 1 ] && echo "    enable=0"
    [ ! -z "$stopOldIpfailover" ] && [ "$stopOldIpfailover" -eq 1 ] && echo "    routes=__TOBEREMOVED__"
    [ ! -z "$stopOldIpfailover" ] && [ "$stopOldIpfailover" -eq 1 ] && echo "    successcount=__TOBEREMOVED__"
    [ ! -z "$stopOldIpfailover" ] && [ "$stopOldIpfailover" -eq 1 ] && echo "    principal=__TOBEREMOVED__"
    [ ! -z "$stopOldIpfailover" ] && [ "$stopOldIpfailover" -eq 1 ] && echo "    rescue=__TOBEREMOVED__"
    [ ! -z "$stopOldIpfailover" ] && [ "$stopOldIpfailover" -eq 1 ] && echo "    checkfreq=__TOBEREMOVED__"
    [ ! -z "$stopOldIpfailover" ] && [ "$stopOldIpfailover" -eq 1 ] && echo "    returnfreq=__TOBEREMOVED__"
    [ ! -z "$stopOldIpfailover" ] && [ "$stopOldIpfailover" -eq 1 ] && echo "    successcount=__TOBEREMOVED__"
    [ ! -z "$stopOldIpfailover" ] && [ "$stopOldIpfailover" -eq 1 ] && echo "    tmtpingresp=__TOBEREMOVED__"
    [ ! -z "$stopOldIpfailover" ] && [ "$stopOldIpfailover" -eq 1 ] && echo "    intervping=__TOBEREMOVED__"
    [ ! -z "$stopOldIpfailover" ] && [ "$stopOldIpfailover" -eq 1 ] && echo "    intervaddrt=__TOBEREMOVED__"
    [ ! -z "$stopOldIpfailover" ] && [ "$stopOldIpfailover" -eq 1 ] && echo "    countaddrt=__TOBEREMOVED__"
    [ ! -z "$stopOldIpfailover" ] && [ "$stopOldIpfailover" -eq 1 ] && echo "    rescuesvp=__TOBEREMOVED__"
    [ ! -z "$stopOldIpfailover" ] && [ "$stopOldIpfailover" -eq 1 ] && echo "    rescueroutes=__TOBEREMOVED__"
    [ ! -z "$stopOldIpfailover" ] && [ "$stopOldIpfailover" -eq 1 ] && echo "    rescuecheckfreq=__TOBEREMOVED__"
    [ ! -z "$stopOldIpfailover" ] && [ "$stopOldIpfailover" -eq 1 ] && echo "    rescuetmtpingresp=__TOBEREMOVED__"
    [ ! -z "$stopOldIpfailover" ] && [ "$stopOldIpfailover" -eq 1 ] && echo "    rescueintervping=__TOBEREMOVED__"
    [ ! -z "$stopOldCheckVpn" ]   && [ "$stopOldCheckVpn" -eq 1 ]   && echo "[suplog]"
    [ ! -z "$stopOldCheckVpn" ]   && [ "$stopOldCheckVpn" -eq 1 ]   && echo "    networkconfigvpnfile=$VPNCFG"
} > $TMPFILE

[ ! -f "$LRRINI.beforemig" ] && cp "$LRRINI" "$LRRINI.beforemig"
$MICMD -t "$LRRINI" -y -a "$TMPFILE"


# Force failover post install if already called
echo "$LINENO - ipfailover2: force postinstall after possible service activation"
[ -f "$ROOTACT/lrr/failovermgr/postinstall.sh" ] && $ROOTACT/lrr/failovermgr/postinstall.sh

# Force checkvpn2 own route update if activated (and certs already downloaded) before exiting
checkMigrationNfr920 ||  { echo "$LINENO - ==== Migration to NFR920 not requested ... ====" && $CHECKVPN2SH routes ; exit 0 ; }

echo
echo "$LINENO - ======== Migration to NFR920 ... ========"
ready2migrateNfr920 || { echo "$LINENO - ==== Migration to NFR920 aborted ... ====" && exit 0 ; }

# Update routes for failover
updateIpfailover

# Activate NFR920, disable migration, force ipfailover service
{
    echo "$FORLRRINI"
    echo "[suplog]"
    echo "    nfr920=1"
    echo "    migrate2nfr920=0"
    [ "$stopOldCheckVpn" = "1" ]   && echo "    networkconfigvpnfile=$VPNCFG"
    echo "[services]"
    # active checkvpn only if the vpn.cfg has been converted
    [ "$stopOldCheckVpn" = "1" ] && echo "    checkvpn2=1"
    echo "    ipfailover2=1"
    echo "    ipfailover=__TOBEREMOVED__"
    echo "[ifacefailover]"
    echo "    enable=0"
} > $TMPFILE

[ ! -f "$LRRINI.beforenfr920" ] && cp "$LRRINI" "$LRRINI.beforenfr920"
$MICMD -t "$LRRINI" -y -a "$TMPFILE"
if [ "$?" = "0" ]
then
    echo "$LINENO - NFR920 activated"
else
    echo "$LINENO - Failed to activate NFR920 ! Set manually [suplog].nfr920=1 in lrr.ini to activate NFR920."
fi
rm -f $TMPFILE

# Remove deprecated backup restore script
RFFCOUNT=$(find $ROOTACT/usr/etc/lrr/cmd_shells/ -name '*rff*.sh' | wc -l)
if [ $RFFCOUNT -gt 0 ]; then
	echo "$LINENO - Remove deprecated custom backup/restore script in $ROOTACT/usr/etc/lrr/cmd_shells/"
	rm -f $ROOTACT/usr/etc/lrr/cmd_shells/*rff*.sh
fi

echo "$LINENO - ======== Migration to NFR920 terminated ========"
echo
