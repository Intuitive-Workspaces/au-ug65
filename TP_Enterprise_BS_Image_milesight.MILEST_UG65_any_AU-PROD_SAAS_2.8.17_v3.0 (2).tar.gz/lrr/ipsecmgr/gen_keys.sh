#!/bin/sh


# 
# Generation of Private and Public keys for SSH authentication.
#    Private key file can be directly used as <identity> by ssh client (-i <identityfile> option)
#    Public key is in PKCSXX format but can be easily converted to ssh public key format used in authorized_keys file
#
gen_keys() {

	PRIVKEY=$1
	PUBKEY=$2
	TMPFILE=/tmp/tmpkey #$(mktemp)
	
	sub="/C=AU/ST=./L=./O=./OU=./CN=./emailAddress=./"

	#openssl req -nodes -newkey rsa:2048 -outform PEM -new -x509 -keyout ${PRIVKEY} -subj "$sub" -noout -pubkey -out ${PUBKEY} > /dev/null 2>&1
	#openssl req -nodes -newkey rsa:2048 -new -x509 -keyout ${PRIVKEY} -subj "$sub" -noout -pubkey -out ${PUBKEY} > /dev/null 2>&1
	
	openssl genpkey -algorithm RSA -out ${TMPFILE} > /dev/null 2>&1
	if [ $? != 0 ]; then
		rm ${TMPFILE}
		exit
	fi

	# Produce Private key in dropbear/openssh compatible format
	openssl rsa -in ${TMPFILE} -out ${PRIVKEY} > /dev/null 2>&1
	if [ $? != 0 ]; then
		rm ${TMPFILE}
		exit
	fi

	# Produce Public key in PKCS8 format
	openssl rsa -in ${TMPFILE} -pubout -out ${PUBKEY} > /dev/null 2>&1
	if [ $? != 0 ]; then
		rm ${TMPFILE}
		exit
	fi

	# Convert to dropbear format if dropbearconvert is present
	#DROPBEARCONV=$(which dropbearconvert)
	#if [ -n "$DROPBEARCONV" ]; then
	#	dropbearconvert openssh dropbear ${PRIVKEY} ${PRIVKEY} > /dev/null 2>&1
	#fi

	chmod 600 ${PRIVKEY}
	rm ${TMPFILE}
}

#
# Silly printer of Private and Public keys (SSH authentication) 
#
print_keys() {

	PRIVKEY=$1
	PUBKEY=$2

	## echo "<COPY PRIVATE START>"
	## cat ${PRIVKEY}
	## echo "<COPY PRIVATE END>"

#	echo "<COPY PUBLIC START>"
	cat ${PUBKEY}
#	echo "<COPY PUBLIC END>"

}

use()
{
	echo "use: gen_key.sh [--public <pubfilename>] [--private <privfilename>] [<lrruuid>]"
}

#
# Main Test script
#
while [ $# -gt 1 ]
do
	case $1 in
		--private)
			shift
			PRIV_KEY="$1"
			shift
			;;
		--public)
			shift
			PUB_KEY="$1"
			shift
			;;
		*)
			echo "Unknown option '$1'"
			use
			exit 1
	esac
done

LRRUUID=$1
if [ -z "$LRRUUID" -a -f "$ROOTACT/usr/etc/lrr/_parameters.sh" ]
then
	. "$ROOTACT/usr/etc/lrr/_parameters.sh"
	[ ! -z "$LRROUI" -a ! -z "$LRRGID" ] && LRRUUID="$LRROUI-$LRRGID"
fi

if [ -z "$LRRUUID" ]
then
	echo "Missing lrruuid ! Not specified and not found in configuration."
	use
	exit 1
fi

[ -z "$PRIV_KEY" ] && PRIV_KEY=RSA-${LRRUUID}.priv.key
[ -z "$PUB_KEY" ] && PUB_KEY=RSA.pub.key
SSHPUB_KEY=RSA.sshpub.key

if [ ! -d "$(dirname $PRIV_KEY)" ]
then
	mkdir -p "$(dirname $PRIV_KEY)"
	chmod 600 "$(dirname $PRIV_KEY)"
fi

[ ! -d "$(dirname $PUB_KEY)" ] && mkdir -p "$(dirname $PUB_KEY)"

# Generate keys
echo "Generating keys ..."
gen_keys ${PRIV_KEY} ${PUB_KEY}
echo "Keys generated."

# Print Keys
#print_keys ${PRIV_KEY} ${PUB_KEY}

# TEST ONLY
# Generate the authorized keys for test purposes only

#SSHKEYGEN=$(which ssh-keygen)

#if [ -n "$SSHKEYGEN" ]; then
#	KEY=$(ssh-keygen -i -m PKCS8 -f ${PUB_KEY})
#	echo "command="\"LRRUUID=$LRRUUID /bin/sh\"" "$KEY" "$LRRUUID > ${SSHPUB_KEY}
#fi
# TEST ONLY
