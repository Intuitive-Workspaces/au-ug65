#!/bin/sh

urtool -g | grep hwver | cut -d':' -f2 | sed 's/ //g'