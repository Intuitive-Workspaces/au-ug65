#!/bin/sh

# note:
# this script is call for AES keys generation then must support multi-board gateways
# - 1: board #

export PATH=$PATH:$ROOTACT/lrr/com/

. ${ROOTACT}/lrr/com/_functions.sh


get_spidevice $1
if [ -z "$SPIDEVICE" ]; then
    echo "No SPI device for board #${1}"
    exit 1
fi

chip_id_path="/usr/bin/chip_id"

if [ ! -f ${chip_id_path} ]; then
	#test if chip_id is stored somewhere else, it's usually stored in /opt/kona64-pkt-forwarder/dvt/chip_id for Kona64
	chip_id_path=$(find ${ROOTACT} -name chip_id | grep chip_id)
	if [ -z "${chip_id_path}" ]; then
		echo "unidentified"
		exit 1
	fi
fi
#run chip_id and select the LSB / MSB values, returns the version
chip_id_msb=$(eval $chip_id_path -d $SPIDEVICE | grep "MSB" | cut -d " " -f 4| tr '[a-z]' '[A-Z]')
if [ -z "${chip_id_msb}" ]
then
    echo "unidentified"
else
    echo ${chip_id_msb}
fi
