#!/bin/sh

cat $ROOTACT/var/log/lrr/radioparams.txt
exit 0
