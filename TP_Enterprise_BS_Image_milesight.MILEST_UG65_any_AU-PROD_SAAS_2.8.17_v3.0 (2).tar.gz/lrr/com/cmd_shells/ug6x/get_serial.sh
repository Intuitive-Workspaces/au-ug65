#!/bin/sh

urtool -g | grep -E ^sn | cut -d':' -f2 | sed 's/ //g'