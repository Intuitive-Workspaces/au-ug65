#!/bin/sh

#
#

# PATH for sshpass command
PATH=.:$PATH

. /var/run/lrrsystem
. $ROOTACT/lrr/com/system_setting.sh
. $ROOTACT/lrr/com/system_api.sh

cd $ROOTACT/lrr/com
#killall sshpass.x

[ -z "$SSHUSERSUPPORT" ] && SSHUSERSUPPORT=support
[ -z "$SSHPASSSUPPORT" ] && SSHPASSSUPPORT=support
[ -z "$SSHHOSTSUPPORT" ] && SSHHOSTSUPPORT=support1.actility.com
[ -z "$SSHPORTSUPPORT" ] && SSHPORTSUPPORT=81

[ -z "$BKPSSHUSERSUPPORT" ] && BKPSSHUSERSUPPORT=support
[ -z "$BKPSSHPASSSUPPORT" ] && BKPSSHPASSSUPPORT=support
[ -z "$BKPSSHHOSTSUPPORT" ] && BKPSSHHOSTSUPPORT=support2.actility.com
[ -z "$BKPSSHPORTSUPPORT" ] && BKPSSHPORTSUPPORT=81

[ -z "$FTPUSERSUPPORT" ] && FTPUSERSUPPORT=ftp
[ -z "$FTPPASSSUPPORT" ] && FTPPASSSUPPORT=
[ -z "$FTPHOSTSUPPORT" ] && FTPHOSTSUPPORT=support1.actility.com
[ -z "$FTPPORTSUPPORT" ] && FTPPORTSUPPORT=21

[ -z "$BKPFTPUSERSUPPORT" ] && BKPFTPUSERSUPPORT=ftp
[ -z "$BKPFTPPASSSUPPORT" ] && BKPFTPPASSSUPPORT=
[ -z "$BKPFTPHOSTSUPPORT" ] && BKPFTPHOSTSUPPORT=support2.actility.com
[ -z "$BKPFTPPORTSUPPORT" ] && BKPFTPPORTSUPPORT=21


REQUIREDPORT=2009
BREAKCNX=3600

#-o StrictHostKeyChecking is not available on wirmav2
#-Itmt is only available on wirmav2 but it seems it does not work

#echo	"SYSTEM=$SYSTEM"
if [ ! -z "$SSH_OPTION_OPT" ]; then
	SSHOPT=$SSH_OPTION_OPT
else
	case	$SYSTEM in
		fcloc|fclamp|fcpico)
			SSHOPT="-y -N -y -y"
		;;
		*)
			SSHOPT="-y -N -o StrictHostKeyChecking=no"
		;;
	esac
fi

while	[ $# -gt 0 ]
do
	case	$1 in 
		-a)	# Deprecated
			shift
			# AUTOSTART="1"
		;;
		-P)
			shift
			REQUIREDPORT="${1}"
			shift
		;;
		-I)
			shift
			BREAKCNX="${1}"
			shift
		;;
		-K)
			shift
			rm ${HOME}/.ssh/known_hosts
		;;
		-A)
			shift
			SSHHOSTSUPPORT="${1}"
			shift
		;;
		-D)
			shift
			SSHPORTSUPPORT="${1}"
			shift
		;;
		-U)
			shift
			SSHUSERSUPPORT="${1}"
			shift
		;;
		-W)
			shift
			SSHPASSSUPPORT="${1}"
			shift
		;;
		*)
			shift
		;;
	esac
done

if [ -f ${ROOTACT}/lrr/com/_functions.sh ]; then
	. ${ROOTACT}/lrr/com/_functions.sh
fi

KillChild()
{
	ppid="$1"
	[ -z "$ppid" ] && return
	lstpid=$(grep "^PPid:.*$ppid"  /proc/*/status | sed "s?^/proc/??" | sed "s?/.*??" 2>/dev/null)
	echo "child $lstpid"
	kill $lstpid 2> /dev/null
}

ACCOUNT="${SSHUSERSUPPORT}@${SSHHOSTSUPPORT}"
$ROOTACT/lrr/com/ipvxchk.x -6 "${SSHHOSTSUPPORT}"
if	[ $? = "0" ]
then
	REVERSE="[${SSHHOSTSUPPORT}]:${REQUIREDPORT}:[::1]:22"
else
	REVERSE="127.0.0.1:${REQUIREDPORT}:localhost:22"
fi

# -e option of sshpass
SSHPASS=${SSHPASSSUPPORT}
export SSHPASS

# the space (' ') between -R and "${REVERSE}" is mandatory !!!!

echo sshpass.x -e ssh ${SSHOPT} -p${SSHPORTSUPPORT} -R "${REVERSE}" "${ACCOUNT}"
sshpass.x -e ssh ${SSHOPT} -p${SSHPORTSUPPORT} -R "${REVERSE}" "${ACCOUNT}" &
bkgpid=$!
echo	"pidssh $bkgpid remoteport ${REQUIREDPORT}"
BKPTRIED="false"
while	[ $BREAKCNX -gt 0 ]
do
	kill -0 $bkgpid
	if	[ $? != "0" ]
	then
		if [ "$BKPTRIED" = "false" ]; then
			# Try opening SSH session to alternative Support server
			ACCOUNT="${BKPSSHUSERSUPPORT}@${BKPSSHHOSTSUPPORT}"
			REVERSE="127.0.0.1:${REQUIREDPORT}:localhost:22"
			SSHPASS=${BKPSSHPASSSUPPORT}
			export SSHPASS
			echo sshpass.x -e ssh ${SSHOPT} -p${BKPSSHPORTSUPPORT} -R "${REVERSE}" "${ACCOUNT}"
			sshpass.x -e ssh ${SSHOPT} -p${BKPSSHPORTSUPPORT} -R "${REVERSE}" "${ACCOUNT}" &
			bkgpid=$!
			BKPTRIED="true"
		else
			exit	1
		fi
	fi
#	echo	"pidssh $bkgpid still present"
	sleep	1
	BREAKCNX=$(expr $BREAKCNX - 1)
done
[ "$FIRMWARE" = "keros" -o "$SYSTEM" = "ciscoms" -o "$SYSTEM" = "fclamp" ] && KillChild $bkgpid
kill $bkgpid
exit 0
