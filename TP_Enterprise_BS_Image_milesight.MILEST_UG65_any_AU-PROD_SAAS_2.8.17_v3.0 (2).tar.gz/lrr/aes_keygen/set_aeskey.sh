##
## @file
## @author Actility
## @copyright Actility SA
## @ingroup setting
##
## @brief generate AES key on V2 gateways
##
## @details
##
## Compute AES key for each board and add them into $ROOTACT/usr/etc/lrr/custom.ini
## 
## @li [lrr] generateaeskey=0|1 (default: 1)
##   generate aes key and updated custom.ini
##
## @li [lrr] forceaeskey=0|1 (default: 0)
##   force eas key replacement if already defined key doesn't math computed key
##   This option can also be set externally with AES_KEYGEN_FORCE
##   
## 


if [ -f /var/run/lrrsystem ]; then
    # new architecture
    . /var/run/lrrsystem
    . $ROOTACT/lrr/com/system_setting.sh
else
    if [ -z "$ROOTACT" -o -z "$SYSTEM" ]; then
        echo "ERROR: ROOTACT and SYSTEM must be set"
        exit 1
    fi
fi

# check the Semtech Reference Design. If unknown, just try (gateways not using new configuration setting)
if [ ! -z "$SEMTECH_REFDESIGN" ] && [ "$SEMTECH_REFDESIGN" != "2.1" ]; then
    echo "no AES key generation on v${SEMTECH_REFDESIGN} model"
    exit 0
fi

if [ ! -z "$FIRMWARE" ] && [ "$FIRMWARE" = "tekos" ]; then
    echo "no AES key generation on ${FIRMWARE} model"
    exit 0
fi

. $ROOTACT/lrr/com/_functions.sh

AES_KEYGEN_EXE=$ROOTACT/lrr/aes_keygen/aes_keygen.x

# ------------------------------------------------------------------------------
#
# function get_user_ini
#
# 1: section
# 2: keyword
# 3: default value (empty for testing if keyword exists)
#
# return value
# ------------------------------------------------------------------------------

get_user_ini() {
    section=$1
    keyword=$2
    defvalue=$3
    inivalue=$(getIniConf "$ROOTACT/usr/etc/lrr/custom.ini" $section $keyword)
    if [ -z "${inivalue}" ]; then
        inivalue=$(getIniConf "$ROOTACT/usr/etc/lrr/lrr.ini" $section $keyword)
        if [ -z "${inivalue}" ]; then
            inivalue=$defvalue
        fi
    fi
    echo "$inivalue"
}

# ------------------------------------------------------------------------------
#
#   MAIN
#
# ------------------------------------------------------------------------------

# ------------------------------------------------------------------------------
# do not generate keys if forbidden (default is 1: generate keys)
# ------------------------------------------------------------------------------

gensection="lrr"
genkeyword="generateaeskey"
setit=$(get_user_ini $gensection $genkeyword 1)
if [ "${setit}" = 0 ]; then
    echo "Automatic AES key generation disabled"
    exit 0
fi

# ------------------------------------------------------------------------------
# force AES key setting in case of mismatch between already-defined and computed one
# can be set externally with AES_KEYGEN_FORCE to avoid updating configuration file
# or via configuration file for wide deployment
# ------------------------------------------------------------------------------

if [ ! -z "${AES_KEYGEN_FORCE}" ]; then
    forceaeskey=${AES_KEYGEN_FORCE}
else
    forcesection="lrr"
    forcekeyword="forceaeskey"
    forceaeskey=$(get_user_ini $forcesection $forcekeyword 0)
fi
echo "Force AES Key Generation: ${forceaeskey}"


# ------------------------------------------------------------------------------
# is there a Semtech configuration file (not present if unknown OEM)
# if yes, source the file to get variables available for the AES keygen binary
# note: can be used on old gateways independently (not packaged, manufacturer unknown)
#  or with new ones during installation
# ------------------------------------------------------------------------------

if [ ! -z "${MANUFACTURER}" ]; then
    conf=$ROOTACT/lrr/aes_keygen/aes_keygen_${MANUFACTURER}.conf
    if [ ! -f $conf ]; then
        # delivered unpackaged for a quick update
        conf=$ROOTACT/lrr/aes_keygen/aes_keygen.conf
    fi
else
    # old design: manufacturer unknown
    conf=$ROOTACT/lrr/aes_keygen/aes_keygen.conf
fi
echo "Using $conf setting"
if [ ! -f ${conf} ]; then
    echo "ERROR: unknown OEM: no AES keygen configuration file"
    exit 1
fi
# note: "set -a" required to force export of variables defined into conf file
set -a ; . ${conf}

# ------------------------------------------------------------------------------
# is the gateway a V2 gateway?
# ------------------------------------------------------------------------------

if [ -f $ROOTACT/lrr/com/system_api.sh ]; then
    . $ROOTACT/lrr/com/system_api.sh
    SystemGetFilePath "$ROOTACT/lrr/com/cmd_shells" "get_semtech_refdesign.sh"
    script=$sysfilepath
else
    script="$ROOTACT/lrr/com/cmd_shells/$SYSTEM/get_semtech_refdesign.sh"
fi
if [ ! -f $script ]; then
    echo "ERROR: $script not present on the gateway"
    exit 1
fi
refdesign=$($script)
if [ "$refdesign" != "2.1" ]; then
    echo "ERROR: $SYSTEM is not a V2 gateway"
    exit 1
fi

# ------------------------------------------------------------------------------
# retrieve the number of boards from lgw.ini
# ------------------------------------------------------------------------------

nb=$(getIniConf "$ROOTACT/usr/etc/lrr/lgw.ini" "gen" "board")
if [ -z "$nb" ]; then
    nb=1
fi

# ------------------------------------------------------------------------------
# for each board,
# - retrieve the LSB and MSB and add an entry 
# - add a entry per board to a temporary file
# ------------------------------------------------------------------------------

tmpfile=/tmp/aeskey.ini
rm -f ${tmpfile}

i=0
while [ $i -lt $nb ]; do
    lsb=$($ROOTACT/lrr/com/cmd_shells/get_chip_id_lsb.sh $i)
    msb=$($ROOTACT/lrr/com/cmd_shells/get_chip_id_msb.sh $i)
    if [ -z "$lsb" -o "$lsb" = "unidentified" ]; then
        echo "ERROR: cannot retrieve LSB for board #${i}"
        exit 1
    fi
    if [ -z "$msb" -o "$msb" = "unidentified" ]; then
        echo "ERROR: cannot retrieve LSB for board #${i}"
        exit 1
    fi
    echo "board #${i}: LSB: ${lsb}, MSB: ${msb}"

    # remove 0X preceding LSB and MSB if any
    lsb=$(echo $lsb | tr 'a-z' 'A-Z' | cut -f2 -dX) 
    msb=$(echo $msb | tr 'a-z' 'A-Z' | cut -f2 -dX) 

    # generate key
    aeskey=$($AES_KEYGEN_EXE $lsb $msb | grep "KEY:" | awk '{print $2}')
    if [ -z ${aeskey} ]; then
        echo "ERROR: cannot generate AES key"
        exit 1
    fi
    echo "          AES key: $aeskey"

    # if key already exists and there is a mismatch, to be fixed manually
    # by removing existing key for instance or forcing [lrr] setaeskey=0
    section="board:$i"
    keyword="aeskey"
    currentkey=$(getIniConf "$ROOTACT/usr/etc/lrr/custom.ini" $section $keyword)
    if [ -z "${currentkey}" ]; then
        currentkey=$(getIniConf "$ROOTACT/usr/etc/lrr/lrr.ini" $section $keyword)
    fi
    if [ ! -z "${currentkey}" ]; then
        if [ "${currentkey}" != "${aeskey}" ]; then
            if [ "${forceaeskey}" != 1 ]; then
                echo "ERROR: defined ($currentkey) and computed key mismatch"
                echo "  Fix it manually by removing current key for instance"
                echo "  by removing the existing key or by forcing key replacement"
                exit 1
            else
                echo "defined ($currentkey) and computed key mismatch -> key replaced"
            fi
        fi
    fi

    echo "[${section}]" >> $tmpfile
    echo "   ${keyword}=$aeskey" >> $tmpfile

    i=$(($i + 1))
done

# ------------------------------------------------------------------------------
# add temporary file to custom.ini
# ------------------------------------------------------------------------------

$ROOTACT/lrr/moreini/moreini.x -y -t $ROOTACT/usr/etc/lrr/custom.ini -a $tmpfile
