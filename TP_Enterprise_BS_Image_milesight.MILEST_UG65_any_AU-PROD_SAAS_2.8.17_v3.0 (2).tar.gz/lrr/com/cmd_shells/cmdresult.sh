#!/bin/sh

cat $ROOTACT/usr/data/lrr/cmd_shells/${1}.log
exit $?
