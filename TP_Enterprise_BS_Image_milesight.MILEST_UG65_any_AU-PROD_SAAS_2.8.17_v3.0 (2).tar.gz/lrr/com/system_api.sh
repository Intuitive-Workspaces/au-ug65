##
## @file
## @author Actility
## @copyright Actility SA
## @brief System API handling gateway-specific script
##
## @details
## Functions used to retrieve path to file relevant for a  gateway.
## When several scripts exist that could be applicable, the following priority order
## is used:
## @li system-specific script
## @li family script
## @li firmware script
## @li manufacturer script
## @li script located in root directyr except if "noroot" is specified
##
## @ingroup system
##

##
## @fn SystemGetFilePath
## @brief return the file to be run
##
## @details returns the full path of the firs file found in a directory tree considering the following oder (per priority)
##
## @param root       root for file searching
## @param filename   file to be used
## @param option     "noroot" if root directory must be excluded.
##                   avoid a script located at the root to call itself
##
## @retval sysfilepath     file if it exists, empty string otherwise
##

SystemGetFilePath() {
    _root=$1
    _filename=$2
    _option=$3

    # does SYSTEM-specific file exist?
    if [ ! -z "${SYSTEM}" ]; then
        sysfilepath=${_root}/${SYSTEM}/${_filename}
        if [ -f "${sysfilepath}" ]; then
            return
        fi
    fi

    # does FAMILY-specific file exist?
    if [ ! -z "${FAMILY}" ]; then
        sysfilepath=${_root}/${FAMILY}/${_filename}
        if [ -f "${sysfilepath}" ]; then
            return
        fi
    fi

    # does FIRMWARE-specific file exist?
    if [ ! -z "${FIRMWARE}" ]; then
        sysfilepath=${_root}/${FIRMWARE}/${_filename}
        if [ -f "${sysfilepath}" ]; then
            return
        fi
    fi

    # does MANUFACTURER-specific file exist?
    if [ ! -z "${MANUFACTURER}" ]; then
        sysfilepath=${_root}/${MANUFACTURER}/${_filename}
        if [ -f "${sysfilepath}" ]; then
            return
        fi
    fi

    # do not return script at root (avoid a root script to execute itself)
    if [ "$_option" = "noroot" ]; then
        sysfilepath=""
        return
    fi

    # does generic file exist?
    sysfilepath=${_root}/${_filename}
    if [ -f "${sysfilepath}" ]; then
        return
    fi

    sysfilepath=""
    return
}

##
## @fn SystemGetFileList
## @brief return the list of all files in reverse priority order 
## @details returns the full path of the all files found in a directory tree in the reverse order of importance
## 
## @param root          root for file searching
## @param filename      file to be searched
## @param option        "noroot" if root directory must not be included
##                      avoid script at root to be considered
## 
## @retval sysfilelist  space-separated file list
##    
SystemGetFileList() {
    _root=$1
    _filename=$2
    _option=$3

    sysfilelist=""
   
    # does generic file exist?
    if [ "${_option}" != "noroot" ]; then
        _filepath=${_root}/${_filename}
        if [ -f "${_filepath}" ]; then
            sysfilelist="$sysfilelist $_filepath"
        fi
    fi

    # does MANUFACTURER-specific file exist?
    if [ ! -z "${MANUFACTURER}" ]; then
        _filepath=${_root}/${MANUFACTURER}/${_filename}
        if [ -f "${_filepath}" ]; then
            sysfilelist="$sysfilelist $_filepath"
        fi
    fi

    # does FIRMWARE-specific file exist?
    if [ ! -z "${FIRMWARE}" ]; then
        _filepath=${_root}/${FIRMWARE}/${_filename}
        if [ -f "${_filepath}" ]; then
            sysfilelist="$sysfilelist $_filepath"
        fi
    fi

    # does FAMILY-specific file exist?
    if [ ! -z "${FAMILY}" ]; then
        _filepath=${_root}/${FAMILY}/${_filename}
        if [ -f "${_filepath}" ]; then
            sysfilelist="$sysfilelist $_filepath"
        fi
    fi

    # does SYSTEM-specific file exist? 
    if [ ! -z "${SYSTEM}" ]; then
        _filepath=${_root}/${SYSTEM}/${_filename}
        if [ -f "${_filepath}" ]; then
            sysfilelist="$sysfilelist $_filepath"
        fi
    fi

}

_test_api=0
if [ "$_test_api" = 1 ]; then

    source ${ROOTACT}/lrr/system/system_definition.sh

    echo "SYSTEM=$SYSTEM"
    echo "FAMILY=$FAMILY"
    echo "FIRMWARE=$FIRMWARE"
    echo "MANUFACTURER=$MANUFACTURER"

    SystemGetFilePath "/tmp/sysapi" "test.sh"
    echo "FILEPATH=$sysfilepath"

    SystemGetFileList "/tmp/sysapi" "test.sh"
    echo "FILELIST=$sysfilelist"
fi
