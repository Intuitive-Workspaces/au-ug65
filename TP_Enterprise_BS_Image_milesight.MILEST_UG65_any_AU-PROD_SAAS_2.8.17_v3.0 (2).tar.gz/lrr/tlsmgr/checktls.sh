#!/bin/sh
#
#   checktls.sh
#
#   Monitor TLS state

#exec 2> /dev/null

LSTCNX="lrc1 lrc2"
VERSION="1.0.0"

################################################################################
# Configurations
################################################################################

CMDNAME="stunnel"
CMDTLS="${ROOTACT}/lrr/stunnel/${CMDNAME}"

export PATH="$PATH:${ROOTACT}/lrr/com/"
LOCAL_ETC="${ROOTACT}/usr/etc/lrr"
CONFIGFILE="${LOCAL_ETC}/stunnel.conf"
CERTFILE="${LOCAL_ETC}/certs/client.pem"
LRRINI="${LOCAL_ETC}/lrr.ini"
BOOTSERVERINI="${LOCAL_ETC}/bootserver.ini"
INFRAINI="${LOCAL_ETC}/infra.ini"
LRRINI_DFT="${ROOTACT}/lrr/config/lrr.ini"
TLSDATA=${ROOTACT}/usr/data/tls
IDENTITYFILE="${LOCAL_ETC}/id_lrr"  ## NFO to be adjusted

################################################################################
################################################################################

# get LRR UUID
if [ -f $ROOTACT/usr/etc/lrr/_parameters.sh ]
then
    . $ROOTACT/usr/etc/lrr/_parameters.sh
fi
# get basic functions
if [ -f ${ROOTACT}/lrr/com/_functions.sh ]
then
    . ${ROOTACT}/lrr/com/_functions.sh
fi

LRR_UUID=$(echo "$LRROUI-$LRRGID" | tr '[a-z]' '[A-Z]')

DECRYPTION_KEY=$(echo "pass:")
DECRYPTION_KEY=$DECRYPTION_KEY"$(echo "$LRROUI-$LRRGID" | tr '[a-z]' '[A-Z]')"

LOCAL_VPN_KEYS="$LOCAL_ETC/localkeys"

TUNNELSTART="${CMDTLS} ${CONFIGFILE}"

LOOPWAIT=120             		# Time (seconds) between each check
MAXWAITCONFIGURING=240  		# Max time waiting in state configuring before trying a restart
MAXWAITDISCONNECTED=1800		# Max time waiting disconnected before trying to get a new configuration
LASTUP=0	  			# last time the VPN was up
LASTUP_BEFORE_NEW_CONF=$(date +%s)	# Initialization - Initial time or last time the VPN was up
VERBOSE=no


get_opt() {
  sed -e "s;^[[:space:]]*;;" -e "s;[[:space:]]*$;;" \
    -e "s;[[:space:]]*=[[:space:]]*;=;" "$1" |
    grep -i "^$2=" | sed -e "s;^[^=]*=;;"
}

get_pid() {
  if [ -f $CONFIGFILE ]; then
    PIDFILE=`get_opt $CONFIGFILE pid`

    if [ -f ${PIDFILE} ] ; then
	PID=$(cat $PIDFILE)
	echo "$PID"
    fi
  fi
}


_get_ini_conf()
{
    conffile_1="$1"
    conffile_2="$2"
    conf_section="$3"
    conf_key="$4"
    
    conf_val=$(getIniConf ${conffile_1} ${conf_section} ${conf_key} || echo "")
    if [ -z "$conf_val" ] ; then
	conf_val=$(getIniConf ${conffile_2} ${conf_section} ${conf_key} || echo "")
    fi

    echo ${conf_val}
    return 1
}


pid_alive() {
    kill -0 $1 2> /dev/null
}
    
get_procname() {
    pid=$1

    if [ ! -z "$pid" ] && pid_alive $pid ; then
	out=$(basename $(cat /proc/$pid/cmdline | tr '\000' ' ' | sed -e "s;^[[:space:]]*;;" -e "s;[[:space:]]\+; ;g" | cut -f1 -d' '))
	echo $out
    fi
}

is_localhost()
{
    addr=$1

    if [ "$addr" = "localhost" ] ; then
       echo ${addr}
       return 0
    fi

    test_res=$(echo $addr | sed -n '/^[[:alnum:]_-]\+\.localdomain$/p')
    if [ ! -z "${test_res}" ] ; then
       echo ${addr}
       return 0
    fi
    
    if [ "$addr" = "::1" ] ; then
	echo "::"
	return 0
    fi

    if [ "$addr" = "127.0.0.1" ] ; then
	echo ${addr}
	return 0
    fi

    echo ""
    return 1
}

gen_stunnel_conf()
{
    DBG_LOG "Generate stunnel.conf"
    
    if [ ! -f ${LRRINI} ] ; then
	DBG_LOG "lrr.ini file does not exists"
	return 1
    fi

    ########################################
    # LAPLRC:0
    ########################################
    lap0_tls=$(_get_ini_conf ${INFRAINI} ${LRRINI} "laplrc:0" "tls")
    lap0_cn=$(_get_ini_conf ${INFRAINI} ${LRRINI} "laplrc:0" "cn")
    lap0_addr=$(_get_ini_conf ${INFRAINI} ${LRRINI} "laplrc:0" "addr")
    lap0_port=$(_get_ini_conf ${INFRAINI} ${LRRINI} "laplrc:0" "port")

    
    if [ ! -z "$lap0_tls" ] ; then
	if [ -z "$lap0_cn" ] ; then
	    DBG_LOG "[laplrc:0] CN is not set ..."
	    lap0_tls=""
	fi
	if [ -z "$lap0_port" ] ; then
	    DBG_LOG "[laplrc:0] local port is not set"
	    lap0_tls=""
	fi
	lap0_addr=$(is_localhost $lap0_addr)
	if [ -z "$lap0_addr" ] ; then
	    DBG_LOG "[laplrc:0] local addr is not set or does not contain localhost"
	    lap0_tls=""
	fi
    fi
    
    ########################################
    # LAPLRC:1
    ########################################
    lap1_tls=$(_get_ini_conf ${INFRAINI} ${LRRINI} "laplrc:1" "tls")
    lap1_cn=$(_get_ini_conf ${INFRAINI} ${LRRINI} "laplrc:1" "cn")
    lap1_addr=$(_get_ini_conf ${INFRAINI} ${LRRINI} "laplrc:1" "addr")
    lap1_port=$(_get_ini_conf ${INFRAINI} ${LRRINI} "laplrc:1" "port")
    
    if [ ! -z "$lap1_tls" ] ; then
	if [ -z "$lap1_cn" ] ; then
	    DBG_LOG "[laplrc:1] CN is not set ..."
	    lap1_tls=""
	fi
	if [ -z "$lap1_port" ] ; then
	    DBG_LOG "[laplrc:1] local port is not set"
	    lap1_tls=""
	fi
	lap1_addr=$(is_localhost $lap1_addr)
	if [ -z "$lap1_addr" ] ; then
	    DBG_LOG "[laplrc:1] local addr is not set or does not contain localhost"
	    lap1_tls=""
	fi
    fi

    ########################################
    # DOWNLOAD:0
    ########################################
    dn0_tls=$(_get_ini_conf ${INFRAINI} ${LRRINI} "download:0" "ftptls")
    dn0_cn=$(_get_ini_conf ${INFRAINI} ${LRRINI} "download:0" "cn")
    dn0_addr=$(_get_ini_conf ${INFRAINI} ${LRRINI} "download:0" "ftpaddr")
    dn0_port=$(_get_ini_conf ${INFRAINI} ${LRRINI} "download:0" "ftpport")

    if [ ! -z "$dn0_tls" ] ; then
	if [ -z "$dn0_cn" ] ; then
	    DBG_LOG "[download:0] CN is not set ..."
	    dn0_tls=""
	fi
	if [ -z "$dn0_port" ] ; then
	    DBG_LOG "[download:0] local port is not set"
	    dn0_tls=""
	fi
	dn0_addr=$(is_localhost $dn0_addr)
	if [ -z "$dn0_addr" ] ; then
	    DBG_LOG "[download:0] local addr is not set or does not contain localhost"
	    dn0_tls=""
	fi
    fi

    ########################################
    # DOWNLOAD:1
    ########################################
    dn1_tls=$(_get_ini_conf ${INFRAINI} ${LRRINI} "download:1" "ftptls")
    dn1_cn=$(_get_ini_conf ${INFRAINI} ${LRRINI} "download:1" "cn")
    dn1_addr=$(_get_ini_conf ${INFRAINI} ${LRRINI} "download:1" "ftpaddr")
    dn1_port=$(_get_ini_conf ${INFRAINI} ${LRRINI} "download:1" "ftpport")

    if [ ! -z "$dn1_tls" ] ; then
	if [ -z "$dn1_cn" ] ; then
	    DBG_LOG "[download:1] CN is not set ..."
	    dn1_tls=""
	fi
	if [ -z "$dn1_port" ] ; then
	    DBG_LOG "[download:1] local port is not set"
	    dn1_tls=""
	fi
	dn1_addr=$(is_localhost $dn1_addr)
	if [ -z "$dn1_addr" ] ; then
	    DBG_LOG "[download:1] local addr is not set or does not contain localhost"
	    dn1_tls=""
	fi
    fi

    ########################################
    # SUPPORT:0
    ########################################
    sup0_tls=$(_get_ini_conf ${INFRAINI} ${LRRINI} "support:0" "ftptls")
    sup0_cn=$(_get_ini_conf ${INFRAINI} ${LRRINI} "support:0" "cn")
    sup0_addr=$(_get_ini_conf ${INFRAINI} ${LRRINI} "support:0" "ftpaddr" || echo "")
    sup0_port=$(_get_ini_conf ${INFRAINI} ${LRRINI} "support:0" "ftpport" || echo "")

    if [ ! -z "$sup0_tls" ] ; then
	if [ -z "$sup0_cn" ] ; then
	    DBG_LOG "[support:0] CN is not set ..."
	    sup0_tls=""
	fi
	if [ -z "$sup0_port" ] ; then
	    DBG_LOG "[support:0] local port is not set"
	    sup0_tls=""
	fi
	sup0_addr=$(is_localhost $sup0_addr)
	if [ -z "$sup0_addr" ] ; then
	    DBG_LOG "[support:0] local addr is not set or does not contain localhost"
	    sup0_tls=""
	fi
    fi

    ########################################
    # SUPPORT:1
    ########################################
    sup1_tls=$(_get_ini_conf ${INFRAINI} ${LRRINI} "support:1" "ftptls")
    sup1_cn=$(_get_ini_conf ${INFRAINI} ${LRRINI} "support:1" "cn")
    sup1_addr=$(_get_ini_conf ${INFRAINI} ${LRRINI} "support:1" "ftpaddr")
    sup1_port=$(_get_ini_conf ${INFRAINI} ${LRRINI} "support:1" "ftpport")

    if [ ! -z "$sup1_tls" ] ; then
	if [ -z "$sup1_cn" ] ; then
	    DBG_LOG "[support:1] CN is not set ..."
	    sup1_tls=""
	fi
	if [ -z "$sup1_port" ] ; then
	    DBG_LOG "[support:1] local port is not set"
	    sup1_tls=""
	fi
	sup1_addr=$(is_localhost $sup1_addr)
	if [ -z "$sup1_addr" ] ; then
	    DBG_LOG "[support:1] local addr is not set or does not contain localhost"
	    sup1_tls=""
	fi
    fi

    if [ -f ${BOOTSERVERINI} ] ; then
		########################################
		# BOOTSERVER
		########################################
		boot0_tls=$(_get_ini_conf ${INFRAINI} ${BOOTSERVERINI} "bootserver:0" "tls")
		boot0_cn=$(_get_ini_conf ${INFRAINI} ${BOOTSERVERINI} "bootserver:0" "cn")
		boot0_addr=$(_get_ini_conf ${INFRAINI} ${BOOTSERVERINI} "bootserver:0" "addr")
		boot0_port=$(_get_ini_conf ${INFRAINI} ${BOOTSERVERINI} "bootserver:0" "port")

		if [ ! -z "$boot0_tls" ] ; then
			if [ -z "$boot0_cn" ] ; then
				DBG_LOG "[bootserver:0] CN is not set ..."
				boot0_tls=""
			fi
			if [ -z "$boot0_port" ] ; then
				DBG_LOG "[bootserver:0] local port is not set"
				boot0_tls=""
			fi
			boot0_addr=$(is_localhost $boot0_addr)
			if [ -z "$boot0_addr" ] ; then
				DBG_LOG "[bootserver:0] local addr is not set or does not contain localhost"
				boot0_tls=""
			fi
		fi

		########################################
		# BOOTSERVER
		########################################
		boot1_tls=$(_get_ini_conf ${INFRAINI} ${BOOTSERVERINI} "bootserver:1" "tls")
		boot1_cn=$(_get_ini_conf ${INFRAINI} ${BOOTSERVERINI} "bootserver:1" "cn")
		boot1_addr=$(_get_ini_conf ${INFRAINI} ${BOOTSERVERINI} "bootserver:1" "addr")
		boot1_port=$(_get_ini_conf ${INFRAINI} ${BOOTSERVERINI} "bootserver:1" "port")

		if [ ! -z "$boot1_tls" ] ; then
			if [ -z "$boot1_cn" ] ; then
				DBG_LOG "[bootserver:1] CN is not set ..."
				boot1_tls=""
			fi
			if [ -z "$boot1_port" ] ; then
				DBG_LOG "[bootserver:1] local port is not set"
				boot1_tls=""
			fi
			boot1_addr=$(is_localhost $boot1_addr)
			if [ -z "$boot1_addr" ] ; then
				DBG_LOG "[bootserver:1] local addr is not set or does not contain localhost"
				boot1_tls=""
			fi
		fi


	fi
	
    cat <<EOF > ${CONFIGFILE}
pid=${TLSDATA}/stunnel.pid
cert=${LOCAL_ETC}/certs/client.pem
key=${LOCAL_ETC}/private/client.key
CAfile=${LOCAL_ETC}/cachain/server_chain.pem
;CAfile=${LOCAL_ETC}/cacerts/server.p12
;CApath=${LOCAL_ETC}/cacerts
EOF

    if [ ! -z "$lap0_tls" ] ; then
	cat <<EOF >> ${CONFIGFILE}
	
[laplrc:0]
   connect=${lap0_tls}
   client=yes
   accept=${lap0_addr}:${lap0_port}
   sni=${lap0_cn}
   verifyChain=yes
   checkHost=${lap0_cn}
EOF
    fi
	
    if [ ! -z "$lap1_tls" ] ; then
	cat <<EOF >> ${CONFIGFILE}
    
[laplrc:1]
   connect=${lap1_tls}
   client=yes
   accept=${lap1_addr}:${lap1_port}
   sni=${lap1_cn}
   verifyChain=yes
   checkHost=${lap1_cn}
EOF
    fi
    
    if [ ! -z "$dn0_tls" ] ; then
	cat <<EOF >> ${CONFIGFILE}

[download:0]
   connect=${dn0_tls}
   client=yes
   accept=${dn0_addr}:${dn0_port}
   sni=${dn0_cn}
   verifyChain=yes
   checkHost=${dn0_cn}
EOF
    fi
    
    if [ ! -z "$dn1_tls" ] ; then
	cat <<EOF >> ${CONFIGFILE}

[download:1]
   connect=${dn1_tls}
   client=yes
   accept=${dn1_addr}:${dn1_port}
   sni=${dn1_cn}
   verifyChain=yes
   checkHost=${dn1_cn}
EOF
    fi

    if [ ! -z "$sup0_tls" ] ; then
	cat <<EOF >> ${CONFIGFILE}

[support:0]
   connect=${sup0_tls}
   client=yes
   accept=${sup0_addr}:${sup0_port}
   sni=${sup0_cn}
   verifyChain=yes
   checkHost=${sup0_cn}
EOF
    fi	

    if [ ! -z "$sup1_tls" ] ; then
	cat <<EOF >> ${CONFIGFILE}

[support:1]
   connect=${sup1_tls}
   client=yes
   accept=${sup1_addr}:${sup1_port}
   sni=${sup1_cn}
   verifyChain=yes
   checkHost=${sup1_cn}
EOF
    fi

    if [ ! -z "$boot0_tls" ] ; then
	cat <<EOF >> ${CONFIGFILE}

[bootserver:0]
   connect=${boot0_tls}
   client=yes
   accept=${boot0_addr}:${boot0_port}
   sni=${boot0_cn}
   verifyChain=yes
   checkHost=${boot0_cn}
EOF
    fi

    if [ ! -z "$boot1_tls" ] ; then
	cat <<EOF >> ${CONFIGFILE}

[bootserver:1]
   connect=${boot1_tls}
   client=yes
   accept=${boot1_addr}:${boot1_port}
   sni=${boot1_cn}
   verifyChain=yes
   checkHost=${boot1_cn}
EOF
    fi
}




DBG_LOG() {
    [ "$VERBOSE" = "yes" ] && echo "$1"
}

CheckTLSEnabled()
{
    checktls_enabled=""

    if [ -f ${LRRINI} ] ; then
	checktls_enabled=$(getIniConf ${LRRINI} "services" "tls" || echo "")
    fi

    if [ -z "$checktls_enabled" ] ; then
	checktls_enabled=$(getIniConf ${LRRINI_DFT} "services" "tls" || echo "")
    fi

    if [ ! -z "$checktls_enabled" -a $checktls_enabled -eq 1 ] ; then
	DBG_LOG "checkTLS enabled"
	return 0
    else
	DBG_LOG "checkTLS disabled"
	return 1
    fi
}


# Check if TLS is configured
CheckTLSConfigured()
{
    DBG_LOG "Check TLS configuration"

    if [ ! -f "$CMDTLS" ]
    then
        DBG_LOG "stunnel not installed"
        return 1
    fi

    if [ ! -f "$CONFIGFILE" ] ; then
        DBG_LOG "No TLS config file"
        return 1
    fi
    
    res=$(grep lrc $CONFIGFILE)
    if [ -z "$res" ] || [ ! -f ${CERTFILE} ]
    then
        DBG_LOG "TLS tunnel not configured in ${CONFIGFILE}"
        return 1
    else
        DBG_LOG "TLS tunnel configured"
        return 0
    fi
}

GetLocalTLSKeys() {
    echo "None"
}


# Get initial TLS keys/certs
GetTLSCerts()
{
    DBG_LOG "Getting TLS keys/certs"

    # start configuration
    VPN_CFG="${LOCAL_ETC}/vpn.cfg"
    if [ ! -f "$VPN_CFG" ]
    then
	echo "No vpn.cfg file $VPN_CFG"
        if [ -z "$LOCAL_VPN_KEYS" ]
        then
            DBG_LOG "Missing download server cfg file"
        else
            # Retrieve initial local VPN keys
            GetLocalTLSKeys
        fi
        return 1
    fi

    PLATFORM=$(get_opt $VPN_CFG "PLATFORM")
    OPERATOR=$(get_opt $VPN_CFG "OPERATOR")

    SFTP=$(get_opt $VPN_CFG "SRV")
    ID=$(get_opt $VPN_CFG "PRESTAGER")
    KEY=$(get_opt $VPN_CFG "KEY")
    PASS=$(get_opt $VPN_CFG "PASS")
    USE_IDENTITY=$(get_opt $VPN_CFG "USE_IDENTITY")
    PORT=$(get_opt $VPN_CFG "PORT")
    [ -z "$PORT" ] && PORT=22

    CFG_TAR="Lrr_${PLATFORM}_${OPERATOR}_${LRR_UUID}.tar.gz"
    ENC_TAR="${CFG_TAR}.enc"

    if [ -z "$SFTP" -o -z "$ID" -o -z "$KEY" -o -z "$PASS" -o -z "$PORT" ]
    then
        DBG_LOG "Missing download server configuration"
        return 1
    fi

    if [ "${USE_IDENTITY}" = "1" ]; then
        USER=$(get_opt $VPN_CFG "USER")
    else
        USER="download${ID}"
    fi
    LOC_DIR="/tmp/secure"
    SRV_DIR="/Lrr_${PLATFORM}_${OPERATOR}_${LRR_UUID}"

    [ ! -d "${LOC_DIR}" ] && mkdir ${LOC_DIR}
    cd ${LOC_DIR}

    password=$(echo "$PASS" | openssl enc -aes-256-cbc -base64 -d -pass pass:"${KEY}+${ID}" | awk '{ printf $1 }')
    if [ -z "$password" ]
    then
        DBG_LOG "Wrong password!"
        return 1
    fi

    DBG_LOG "Retrieving ${SRV_DIR}/${ENC_TAR}"
    if [ "${USE_IDENTITY}" = "1" ]; then
        lrr_DownloadFromRemote -u ${USER} -i ${IDENTITYFILE} -p ${PORT} -a ${SFTP} -r ${SRV_DIR}/${ENC_TAR} -l ${LOC_DIR}/${ENC_TAR} -s 1
    else
        lrr_DownloadFromRemote -u ${USER} -w ${password} -p ${PORT} -a ${SFTP} -r ${SRV_DIR}/${ENC_TAR} -l ${LOC_DIR}/${ENC_TAR} -s 1
    fi

    if [ ! -f "${ENC_TAR}" ]
    then
        DBG_LOG "Couldn't retrieve configuration files."
        return 1;
    fi

    openssl enc -aes-256-cbc -d -in ${ENC_TAR} -out ${CFG_TAR} -pass $DECRYPTION_KEY
    tar xvf ${CFG_TAR}
    if [ $? == 0 ]
    then
	cp -r $ID/Lrr_${PLATFORM}_${OPERATOR}_${LRR_UUID}/cacerts ${LOCAL_ETC}
	mkdir -p ${LOCAL_ETC}/cachain
	mkdir -p ${LOCAL_ETC}/certs
	mkdir -p ${LOCAL_ETC}/private
	cp $ID/Lrr_${PLATFORM}_${OPERATOR}_${LRR_UUID}/cachain/*.pem ${LOCAL_ETC}/cachain/server_chain.pem
	cp $ID/Lrr_${PLATFORM}_${OPERATOR}_${LRR_UUID}/certs/*.pem   ${LOCAL_ETC}/certs/client.pem
	cp $ID/Lrr_${PLATFORM}_${OPERATOR}_${LRR_UUID}/private/*.key ${LOCAL_ETC}/private/client.key
	
	cp $ID/Lrr_${PLATFORM}_${OPERATOR}_${LRR_UUID}/infra.ini     ${INFRAINI}
	
	chmod 644 ${LOCAL_ETC}/certs/*
	chmod 600 ${LOCAL_ETC}/private/*

	# Install Certicates (Install their hash.0 links)
	#     See openssl -CApath in manual for more informations
	cd ${LOCAL_ETC}/cacerts
	for fname in $(ls *.pem) ; do
	    hash=$(openssl x509 -subject_hash -noout -in $fname)
	    ln -fs $fname $hash.0
	done
	cd -

	# Push an empty file on the SFTP server, under the /done subdirectory, to indicate that the archive has been downloaded and handled correctly
	# Then, for security reasons, the SFTP server will delete the archive
	echo > ${ENC_TAR}

    DBG_LOG "Ask for file deletion on the SFTP server"
    if [ "${USE_IDENTITY}" = "1" ]; then
        lrr_UploadToRemote -u ${USER} -i ${IDENTITYFILE} -a ${SFTP} -p ${PORT} -l ${ENC_TAR} -r "/done/${ENC_TAR}" -s 1
    else
        lrr_UploadToRemote -u ${USER} -w ${password} -a ${SFTP} -p ${PORT} -l ${ENC_TAR} -r "/done/${ENC_TAR}" -s 1
    fi

	DBG_LOG "configuration finished"
	return 0
    else
	DBG_LOG "configuration failed"
	return 1
    fi
}

CleanFiles()
{
    rm -fr ${LOCAL_ETC}/cacerts/
    rm -fr ${LOCAL_ETC}/certs/
    rm -fr ${LOCAL_ETC}/private/
}


################################################################################
# TLS Process managment
################################################################################

# Check if TLS process
CheckTLSProcess()
{
    DBG_LOG "Check $CMDNAME process"

    tlspid=$(get_pid)
    name=$(get_procname $tlspid)

    if [ "$name" = "${CMDNAME}" ] ; then
        DBG_LOG "$CMDNAME process: ok"
        return 0
    else
        DBG_LOG "$CMDNAME process: error"
        return 1
    fi
}

# Start TLS
StartTLSProcess()
{
    DBG_LOG "Starting TLS"

    gen_stunnel_conf

    [ ! -f ${TLSDATA} ] && mkdir -p ${TLSDATA}

    if [ $? -eq 0 ] ; then
	$TUNNELSTART
    else
	return 1
    fi
}

# Stop TLS
StopTLSProcess()
{
    DBG_LOG "Stopping TLS"

    tlspid=$(get_pid)

    if [ ! -z "$tlspid" ] && pid_alive $tlspid ; then 
	DBG_LOG "Need to kill starter"
	kill -9 $tlspid
    fi
}

# Restart TLS
RestartTLSProcess()
{
    StopTLSProcess
    sleep 5
    StartTLSProcess
}

Use()
{
    echo "checktls.sh [-V] || [-v] start|stop|clean"
    echo "  -v: verbose"
    echo "  -V: get version and exit"
    exit
}

# Reload Configuration
ReloadTLSProcess()
{
    DBG_LOG "Reloading TLS"

    tlspid=$(get_pid)

    gen_stunnel_conf
    
    if [ $? -eq 0 -a ! -z "$tlspid" ] && pid_alive $tlspid ; then 
	DBG_LOG "Reloading proc $tlspid"
	kill -HUP $tlspid
    fi
}

StartMonitoring()
{
    echo "Start monitor"

    CheckTLSEnabled
    enabled=$?

    while [ 1 ]
    do
        [ ! -z "$firstCall" ] && sleep $LOOPWAIT
        firstCall=no
        curDate=$(date +"%d/%m %H:%M:%S")
        DBG_LOG "$curDate Check TLS state"

	if [ $enabled -ne 0 ] ; then
            DBG_LOG "Not Enabled"
	    continue
	fi

        CheckTLSConfigured

        if [ $? -ne 0 ]
        then
            DBG_LOG "Not Configured"
            GetTLSCerts

            CheckTLSProcess
            if [ $? = 0 ]
            then
                ReloadTLSProcess
	    else
		StartTLSProcess
	    fi
	    
        else

            CheckTLSProcess
            # Vpn not started
            if [ $? = 1 ]
            then
		StartTLSProcess
                sleep 10
                continue
            fi

#
# Connection Tracking is not yet available
#
# For reference: checkvpn.sh version
	    
#            CheckVpnCnx
#            # best state is down
#            if [ $? = 0 ]
#            then
#                DBG_LOG "Vpn down, restart"
#                RestartVpnProcess
#                continue
#            # best state is connecting
#            elif [ $? = 1 ]
#            then
#            	now=$(date +%s)
#                restartTime=$(($LASTUP + $MAXWAITCONFIGURING))
#                if [ $restartTime -lt $now ]
#                then
#                	LASTUP=$(date +%s)
#                        echo "In state connecting for more than $MAXWAITCONFIGURING seconds, restart"
#                        CheckVpnCnx
#                fi
#            fi
#	   
#	    # If the gateway has a configuration and cannot be connected for $MAXWAITDISCONNECTED, try to retrieve a new conf 
#	    now=$(date +%s)
#	    newConfTime=$(($LASTUP_BEFORE_NEW_CONF + $MAXWAITDISCONNECTED))
#	    if [ $newConfTime -lt $now ]
#	    then
#		GetVpnKeys
#		LASTUP_BEFORE_NEW_CONF=$(date +%s)
#		RestartVpnProcess
#	    fi		    

        fi
    done
}

#
#       MAIN
#

while [ $# -gt 0 ]
do
        case "$1" in
                "-V")
                        echo "$VERSION"
                        exit
                        ;;
                "-v")
                        VERBOSE="yes"
                        shift
                        ;;
                "start")
                        shift
                        ;;
                "stop")
		        StopTLSProcess
                        #killall $0
			exit
                        ;;
		clean)
		    CleanFiles
		    exit
		    ;;
                *)
                        echo "Unknown option '$1' !"
                        Use
                        shift
                        ;;
        esac
done

StartMonitoring

