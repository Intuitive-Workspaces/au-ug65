#!/bin/sh
#

# check if $ROOTACT directory exists
if	[ ! -d "$ROOTACT" ]
then
	echo	"$ROOTACT does not exist"
	exit	1
fi

DIR=${ROOTACT}/usr/data/lrr/cmd_shells
for cmd in $(ls $DIR)
do
	case $cmd in
	*.log)
		num=$(expr $cmd : '\([0-9][0-9]*\)\.log')
		if [ "$num" = "" ]; then
			continue
		fi
		name=$(grep -m1 cmd_shells ${DIR}/${num}.log)
		if [ -f ${DIR}/${num}_pending ]; then
			state="pending"
			if [ -f ${DIR}/${num}.pid ]; then
				ppid=$(cat ${DIR}/${num}.pid)
				kill -0 $ppid 2>/dev/null 2>&1
				if [ $? != 0 ]; then
					state="error"
				fi
			fi
			echo	"cmdid=$num state=$state"
			echo	"cmd=$name"
			continue
		fi
		if [ -f ${DIR}/${num}_terminated ]; then
			code=$(cat ${DIR}/${num}_terminated)
			echo	"cmdid=$num state=terminated code=$code"
			echo	"cmd=$name"
			continue
		fi
	;;
	*)
	;;
	esac
done

exit 0
