#!/bin/sh

ROOTACT=/home/actility

SYSTEM_ETC=/etc

SERVICEPREFIX="$SYSTEM_ETC/init.d/"

servicelrr=/etc/init.d/lrr

uninstallService()
{
    shname="$1"
    srvname="$2"
    if [ ! -z "$3" ]; then
        srvprio=$3
    else
        srvprio=
    fi

    if [ -d $ROOTACT/lrr/system ]; then
        rm -rf /etc/rc.d/S${srvprio}${srvname}
        rm -rf ${SERVICEPREFIX}$srvname
    fi

}

removeServices()
{
    srvdir="$ROOTACT/lrr/services"

    [ ! -d "$srvdir" ] && return

    # scan all files
    for f in $(ls $srvdir)
    do
        unset SERVICENAME SERVICESOURCE SERVICEPRIORITY ONSYSTEM

        # ignore readme
        [ ! -f "$srvdir/$f" -o "$f" = "readme" ] && continue

        # set SERVICENAME and SERVICESOURCE
        . $srvdir/$f

        # all redesigned gateways should support new services
        # check ONSYSTEM if it is not the new mechanism
        if [ ! -d $ROOTACT/lrr/system ]; then
            # if ONSYSTEM set, activated only if system is specified
            [ ! -z "$ONSYSTEM" -a -z "$(echo $ONSYSTEM | grep $SYSTEM)" ] && continue
        fi

        # check SERVICENAME and SERVICESOURCE
        if [ -z "$SERVICENAME" -o -z "$SERVICESOURCE" ]
        then
            echo "SERVICENAME or SERVICESOURCE not set, file '$f' ignored"
            return
        fi

        # check if SERVICESOURCE file exist
        if [ ! -f "$SERVICESOURCE" ]
        then
            echo "Can't find '$SERVICESOURCE', creation of service '$SERVICENAME' aborted"
            continue
        fi

        # create service
        echo "create service $SERVICENAME"
        if [ -z "$SERVICEPRIORITY" ]; then
            uninstallService "$SERVICESOURCE" "$SERVICENAME"
        else
            uninstallService "$SERVICESOURCE" "$SERVICENAME" "$SERVICEPRIORITY"
        fi
    done
}

stopService()
{
    srvdir="$1"
    srvname="$2"

    [ -z "$srvdir" -o ! -e "$srvdir/$srvname" ] && continue

    unset SERVICENAME SERVICESOURCE ONSYSTEM

    # ignore readme
    [ ! -f "$srvdir/$srvname" -o "$srvname" = "readme" ] && continue

    # set SERVICENAME and SERVICESOURCE
    . $srvdir/$srvname

    # if ONSYSTEM set, activated only if system is specified
    [ ! -z "$ONSYSTEM" -a -z "$(echo $ONSYSTEM | grep $SYSTEM)" ] && continue

    # check SERVICENAME and SERVICESOURCE
    if [ -z "$SERVICENAME" -o -z "$SERVICESOURCE" ]
    then
        echo "SERVICENAME or SERVICESOURCE not set, file '$srvname' ignored"
        return
    fi

    # identify service path

    srv="/etc/init.d/$SERVICENAME"

    # check if service file exists
    if [ ! -f "$srv" ]
    then
        echo "Can't find '$srv', can't stop service"
        continue
    fi

    echo "stop service $SERVICENAME"
    $srv stop
}

stopServices()
{
    srvdir="$ROOTACT/lrr/services"

    [ ! -d "$srvdir" ] && return

    # scan all files
    for f in $(ls $srvdir)
    do
        stopService "$srvdir" "$f"
    done
}

stopServices

removeServices