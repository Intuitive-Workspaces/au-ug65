#!/bin/sh
#
#	backup.sh
#
#	Save all lrr files, binaries and configuration, and some other
#	files needed to restore the connectivity with the lrc
#

if [ -f /var/run/lrrsystem ]; then
    . /var/run/lrrsystem
fi

. $ROOTACT/lrr/com/system_setting.sh
. $ROOTACT/lrr/com/system_api.sh

# check if $ROOTACT directory exists
if	[ ! -d "$ROOTACT" ]
then
	echo	"$ROOTACT does not exist"
	exit	1
fi

if [ -f "$ROOTACT/usr/etc/lrr/_parameters.sh" ]
then
	. $ROOTACT/usr/etc/lrr/_parameters.sh
fi

SystemGetFilePath "$ROOTACT/lrr/restoremgr" "conf"
CONF=$sysfilepath
if [ ! -f "$CONF" ]
then
	echo "Can't find configuration for backup, abort !"
	exit 1
fi

. "$CONF"


VERSION=$(cat $ROOTACT/lrr/Version)
DATEINI=$(date +%FT%T%z)
tm=$(expr $DATEINI : '\(.*\)[-+].*')
tz=$(expr $DATEINI : '.*[-+]\(.*\)')
hh=$(expr $tz : '\([0-9][0-9]\)[0-9][0-9]')
mm=$(expr $tz : '[0-9][0-9]\([0-9][0-9]\)')
isplus=$(echo "$DATEINI" | grep "+")
if [ -z "$isplus" ]
then
	DATE=${tm}.0-${hh}:${mm}
else
	DATE=${tm}.0+${hh}:${mm}
fi

echo "Preparing files for backup, please wait"

# create tar file
[ -f "/tmp/$TARFILE" ] && rm "/tmp/$TARFILE"
echo "tar czf /tmp/$TARFILE $LRRDIR $LRRCONF $LRRDATA $SUPDIR $SYSTEMFILES" >&2
tar czf /tmp/$TARFILE $LRRDIR $LRRCONF $LRRDATA $SUPDIR $SYSTEMFILES
ret=$?

# check tar file
if [ "$ret" = "0" ]
then
	tar tzf /tmp/$TARFILE >/dev/null 2>&1
	ret=$?
fi

if [ "$ret" != "0" ]
then
	echo "Failed to create a valid /tmp/$TARFILE ! COMMAND ABORTED"
	rm -f /tmp/$TARFILE
	exit	1
fi

# copy file in backup directory
[ ! -d "$BACKUPDIR" ] && mkdir -p "$BACKUPDIR"

mv /tmp/$TARFILE $BACKUPDIR
if [ $? = 0 ]
then
	# create file containing backup infos
	{
	echo -e "{\n\"restore\": {"
	echo "  \"backupLrrVersion\": \"$VERSION\","
	echo "  \"backupDate\": \"$DATE\","
	echo "  \"backupLogFile\": \"$BACKUPLOGFILE\""
	echo -e "}\n}"
	} > $BACKUPINFO
	# for compatibility
	SAVERFF=$ROOTACT/usr/etc/lrr/saverff_done
	echo "RFFVERSION=${VERSION}"	> $SAVERFF
	echo "RFFDATE=${DATEINI}"		>> $SAVERFF
else
	echo "Failed to store backup file in backup directory (no space left ?) ! COMMAND ABORTED"
	rm -f /tmp/$TARFILE
	exit	1
fi

#
# some other packages need to add some tarbal ?
#

lst=$(ls ${ROOTACT}/usr/etc/lrr/restoremgr/*.sh 2>/dev/null)
for i in $lst
do
	echo	"add other pkg to backup from $i"
	sh ${i} > /dev/null 2>&1
done

echo "backup done"
exit $?
