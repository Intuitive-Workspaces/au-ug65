#!/bin/sh

. $ROOTACT/lrr/com/system_setting.sh
. $ROOTACT/lrr/com/system_api.sh

SystemGetFilePath "$ROOTACT/lrr/postinstall" "system_postinstall.sh" "noroot"
if [ -f "$sysfilepath" ]; then
    $sysfilepath
fi
