# with new implementation, "env" returns also function definitions making output too big then slow (LRC timeout)
# "set" returns only variables
set | sort
exit 0
