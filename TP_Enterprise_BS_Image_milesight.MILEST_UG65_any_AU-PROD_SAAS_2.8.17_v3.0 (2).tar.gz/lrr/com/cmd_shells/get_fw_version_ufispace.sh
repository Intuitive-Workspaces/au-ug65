#!/bin/sh

cat /etc/mlb-version

