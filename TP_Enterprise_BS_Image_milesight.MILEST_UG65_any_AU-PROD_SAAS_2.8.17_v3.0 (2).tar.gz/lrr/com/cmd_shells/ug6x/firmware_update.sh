#!/bin/sh

ROOTACT=/home/actility

SYSTEM_ETC=/etc

SERVICEPREFIX="$SYSTEM_ETC/init.d/"

servicelrr=/etc/init.d/lrr

installService()
{
    shname="$1"
    srvname="$2"
    if [ ! -z "$3" ]; then
        srvprio=$3
    else
        srvprio=
    fi

    if [ -d $ROOTACT/lrr/system ]; then

        cat $shname | sed "s?_REPLACEWITHROOTACT_?$ROOTACT?" > ${SERVICEPREFIX}$srvname
        chmod +x ${SERVICEPREFIX}$srvname

        [ -z "$srvprio" ] && srvprio=99
        ln -s ${SERVICEPREFIX}$srvname /etc/rc.d/S${srvprio}${srvname}
    fi

}

createServices()
{
    srvdir="$ROOTACT/lrr/services"

    [ ! -d "$srvdir" ] && return

    # scan all files
    for f in $(ls $srvdir)
    do
        unset SERVICENAME SERVICESOURCE SERVICEPRIORITY ONSYSTEM

        # ignore readme
        [ ! -f "$srvdir/$f" -o "$f" = "readme" ] && continue

        # set SERVICENAME and SERVICESOURCE
        . $srvdir/$f

        # all redesigned gateways should support new services
        # check ONSYSTEM if it is not the new mechanism
        if [ ! -d $ROOTACT/lrr/system ]; then
            # if ONSYSTEM set, activated only if system is specified
            [ ! -z "$ONSYSTEM" -a -z "$(echo $ONSYSTEM | grep $SYSTEM)" ] && continue
        fi

        # check SERVICENAME and SERVICESOURCE
        if [ -z "$SERVICENAME" -o -z "$SERVICESOURCE" ]
        then
            echo "SERVICENAME or SERVICESOURCE not set, file '$f' ignored"
            return
        fi

        # check if SERVICESOURCE file exist
        if [ ! -f "$SERVICESOURCE" ]
        then
            echo "Can't find '$SERVICESOURCE', creation of service '$SERVICENAME' aborted"
            continue
        fi

        # create service
        echo "create service $SERVICENAME"
        if [ -z "$SERVICEPRIORITY" ]; then
            installService "$SERVICESOURCE" "$SERVICENAME"
        else
            installService "$SERVICESOURCE" "$SERVICENAME" "$SERVICEPRIORITY"
        fi
    done
}

restartService()
{
    srvdir="$1"
    srvname="$2"

    [ -z "$srvdir" -o ! -e "$srvdir/$srvname" ] && continue

    unset SERVICENAME SERVICESOURCE ONSYSTEM

    # ignore readme
    [ ! -f "$srvdir/$srvname" -o "$srvname" = "readme" ] && continue

    # set SERVICENAME and SERVICESOURCE
    . $srvdir/$srvname

    # if ONSYSTEM set, activated only if system is specified
    [ ! -z "$ONSYSTEM" -a -z "$(echo $ONSYSTEM | grep $SYSTEM)" ] && continue

    # check SERVICENAME and SERVICESOURCE
    if [ -z "$SERVICENAME" -o -z "$SERVICESOURCE" ]
    then
        echo "SERVICENAME or SERVICESOURCE not set, file '$srvname' ignored"
        return
    fi

    # identify service path

    srv="/etc/init.d/$SERVICENAME"

    # check if service file exists
    if [ ! -f "$srv" ]
    then
        echo "Can't find '$srv', can't restart service"
        continue
    fi

    echo "restart service $SERVICENAME"
    $srv restart
}

restartServices()
{
    srvdir="$ROOTACT/lrr/services"

    [ ! -d "$srvdir" ] && return

    # scan all files
    for f in $(ls $srvdir)
    do
        restartService "$srvdir" "$f"
    done
}

#
# add following lines in /etc/profile if not present
#
if [ -z "$INIT_PROF" ]; then
    INIT_PROF=$SYSTEM_ETC/profile
fi
PROF_LINE="export ROOTACT=${ROOTACT}"
SCFG_LINE="export SYSTEM_ETC=${SYSTEM_ETC}"
ADD_PATH=""
if [ "$SYSTEM" = "ciscoms" ]; then
    rm $INIT_PROF
    # to add command wrappers
    ADD_PATH="\$ROOTACT/lrr/com/cmd_shells/$SYSTEM:"
fi
PATH_LINE="export PATH=$ADD_PATH\$PATH:\$ROOTACT/lrr/com:\$ROOTACT/system/bin"
ALIA_LINE="alias cdr='cd \$ROOTACT'"
line=$(grep "$PROF_LINE" $INIT_PROF)
if	[ -z "$line" ]
then
    echo	"ROOTACT not present in $INIT_PROF : add it"
    echo	>> $INIT_PROF
    echo	$PROF_LINE >> $INIT_PROF
    echo	$SCFG_LINE >> $INIT_PROF
    echo	$PATH_LINE >> $INIT_PROF
    echo	$ALIA_LINE >> $INIT_PROF
    echo "alias l='ls --color=auto'" >> $INIT_PROF
    echo "alias ll='ls -l --color=auto'" >> $INIT_PROF
else
    echo	"ROOTACT already present in $INIT_PROF"
fi
if [ -z "$(grep system_setting $INIT_PROF)" ]; then
    echo    "if [ -f "\$ROOTACT/lrr/com/system_setting.sh" ]; then . \$ROOTACT/lrr/com/system_setting.sh ; fi" >> $INIT_PROF
fi

# customize shell to ease daily work of support team
# - autocompletion with only directories on "cd"
mkdir -p /etc/profile.d
cat > /etc/profile.d/customize_shell.sh  <<EOF
complete -d cd 2> /dev/null
EOF
chmod a+x /etc/profile.d/customize_shell.sh

createServices

restartServices