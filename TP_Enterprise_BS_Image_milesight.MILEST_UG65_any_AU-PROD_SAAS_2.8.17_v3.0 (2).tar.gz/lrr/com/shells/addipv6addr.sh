#!/bin/sh

#
# add a routable IPV6 address to eth0, by default address is based on local link
#

# 00) 0000 02 0010 
# 01) 0001 03 0011 
# 02) 0010 00 0000 
# 03) 0011 01 0001 
# 04) 0100 06 0110 
# 05) 0101 07 0111 
# 06) 0110 04 0100 
# 07) 0111 05 0101 
# 08) 1000 0a 1010 
# 09) 1001 0b 1011 
# 0a) 1010 08 1000 
# 0b) 1011 09 1001 
# 0c) 1100 0e 1110 
# 0d) 1101 0f 1111 
# 0e) 1110 0c 1100 
# 0f) 1111 0d 1101 

# invert bit 1 (starting at 0) of the first half octet of mac@
InvertBit1()
{
	case $1 in
	0) echo 2  ;;
	1) echo 3  ;;
	2) echo 0  ;;
	3) echo 1  ;;
	4) echo 6  ;;
	5) echo 7  ;;
	6) echo 4  ;;
	7) echo 5  ;;
	8) echo a  ;;
	9) echo b  ;;
	a) echo 8  ;;
	b) echo 9  ;;
	c) echo e  ;;
	d) echo f  ;;
	e) echo c  ;;
	f) echo d  ;;
	esac
}



if	[ ! -d "$ROOTACT" ]
then
	echo	"#ROOTACT does not exist"
	exit	1
fi

if [ -f ${ROOTACT}/lrr/com/_parameters.sh ]
then
	. ${ROOTACT}/lrr/com/_parameters.sh
fi
if [ -f ${ROOTACT}/lrr/com/_functions.sh ]
then
	. ${ROOTACT}/lrr/com/_functions.sh
fi

lrr_CloseFiles

# old installs do not have SYSTEM in _parameters.sh
if	[ -z "$SYSTEM" ]
then
	SYSTEM=$LRRSYSTEM
fi
export SYSTEM

# generic command

CMD="add"
ITF="eth0"
PRF="aaaa:0000:0000:0000"
# some ifconfig require inet6 directive : ifconfig eth0 <inet6> add addr
#OPT="inet6"
OPT=""
ADR=""

while   [ $# -gt 0 ]
do
	case    $1 in
	-i)
		shift
		ITF=$1
		;;
	-p)
		shift
		PRF=$1
		;;
	-o)
		shift
		OPT=$1
		;;
	-d)
		shift
		CMD=del
		;;
	-f)
		shift
		ADR=$1
		;;
	*)
		shift
		;;
	esac
done

# address is fully passed by caller
if [ "$ADR" != "" ]
then
	echo "ifconfig ${ITF} ${OPT} ${CMD} $ADR"
	ifconfig ${ITF} ${OPT} ${CMD} $ADR
	exit $?
fi

locallink=`ifconfig ${ITF} | grep inet6 | grep "fe80::"`
if [ "$locallink" != "" ]
then	# we already have a local link fe80 well declared
	locallink=`echo $locallink | cut -d ' ' -f3`
	if [ -z "$locallink" ]
	then
		echo	"fail 1.1"
		exit 1
	fi
	locallink=`expr $locallink : "fe80::\(.*\)"`
	if [ -z "$locallink" ]
	then
		echo	"fail 1.2"
		exit 1
	fi
#	echo	"locallink case 1 ${locallink}"
else	# no local link fe80, build it with mac@
	# A:B:C:D:E:F => A{&~0x02 or |0x02}B:Cff:feD:EF
	macaddr=`ifconfig ${ITF} | grep HWaddr`
	if [ -z "$macaddr" ]
	then
		echo	"fail 2.1"
		exit 1
	fi
	macaddr=`echo $macaddr | cut -d ' ' -f5`
	if [ -z "$macaddr" ]
	then
		echo	"fail 2.2"
		exit 1
	fi
#	I give up not all bash support the following for array initialization
#	we use our own exe

##	macaddr=`echo $macaddr | tr ':' ' '`
##	macaddr=`echo $macaddr | tr [A-Z] [a-z]`
##	tabmac=($macaddr)
##	A=${tabmac[0]}
##	Aa=`expr $A : "\([0-9a-f]\)[0-9a-f]"`
##	Ab=`expr $A : "[0-9a-f]\([0-9a-f]\)"`
##	Ac=`InvertBit1 $Ab`
##	A=${Aa}${Ac}
##	locallink="${A}${tabmac[1]}:${tabmac[2]}ff:fe${tabmac[3]}:${tabmac[4]}${tabmac[5]}"
	locallink=`${ROOTACT}/lrr/com/ipv6gs.x ${macaddr}`
	if	[ $? != 0 ]
	then
		echo	"fail 2.3"
		exit 1
	fi
#	echo	"locallink case 2 ${locallink}"
	echo "ifconfig ${ITF} ${OPT} ${CMD} fe80::${locallink}/64"
	ifconfig ${ITF} ${OPT} ${CMD} fe80::${locallink}/64
	locallink=${locallink}/64
fi
routable=${PRF}:${locallink}
#echo $routable

echo "ifconfig ${ITF} ${OPT} ${CMD} ${routable}"
ifconfig ${ITF} ${OPT} ${CMD} ${routable}
exit $?

