#!/bin/sh

#default values

HOST=""
PORT=""
USER=""
PASS=""
SFTP="1"
LOGDIR=""

while	[ $# -gt 0 ]
do
	case	$1 in
		-A)
			shift
			HOST="${1}"
			shift
		;;
		-P)
			shift
			PORT="${1}"
			shift
		;;
		-U)
			shift
			USER="${1}"
			shift
		;;
		-W)
			shift
			PASS="${1}"
			shift
		;;
		-S)
			shift
			SFTP="${1}"
			shift
		;;
		-L)
			shift
			# LOGDIR may not exist yet
			if [ -e "${1}" ]; then
				LOGDIR="${1}"
			fi
			shift
		;;
		-C)
			shift
			CRYPTED="-c"
		;;
		*)
			shift
		;;
	esac
done

[ -z "$HOST" ] && exit 1
[ -z "$PORT" ] && exit 1
[ -z "$USER" ] && exit 1
[ -z "$PASS" ] && exit 1

if [ -f ${ROOTACT}/lrr/com/_parameters.sh ]
then
	. ${ROOTACT}/lrr/com/_parameters.sh
fi
if [ -f ${ROOTACT}/lrr/com/_functions.sh ]
then
	. ${ROOTACT}/lrr/com/_functions.sh
fi
[ -z "$LRRSYSTEM" ] && LRRSYSTEM="$SYSTEM"

LOGFILE="LOGS_$(date '+%y%m%d_%H%M%S').tar.gz"

# check exclude option
tar cf /tmp/test.tar $ROOTACT/lrr/Version --exclude toto >/dev/null 2>&1
[ $? = 0 ] && EXCLUDE="--exclude $(echo $ROOTACT | sed 's?^/??')/usr/etc/lrr/private"
rm -f /tmp/test.tar

# tar directories
tarfile="/tmp/sendlog.tar"
rm -f $tarfile $tarfile.gz
if [ "$TAR_OPTION_X" = "y" -o "$SYSTEM" = "fcmlb" -o "$SYSTEM" = "fcpico" -o "$SYSTEM" = "fcloc" -o "$SYSTEM" = "fclamp" -o "$SYSTEM" = "flexpico" ]; then
	fileexclude="/tmp/_tarexclude$$"
	echo "$(echo $ROOTACT | sed 's?^/??')/usr/etc/lrr/private" > $fileexclude
	[ "$SYSTEM" != "ciscoms" ] && echo /var/log/messages >> $fileexclude
	tar cvhf $tarfile -X $fileexclude $ROOTACT/var/log/lrr $ROOTACT/usr/etc/lrr $ROOTACT/lrr/config $LOGDIR
        rm -f $fileexclude
else
	EXCLUDE="--exclude $(echo $ROOTACT | sed 's?^/??')/usr/etc/lrr/private"
	[ "$SYSTEM" != "ciscoms" ] && EXCLUDE="$EXCLUDE /var/log/messages"
	tar cvhf $tarfile $ROOTACT/var/log/lrr $ROOTACT/usr/etc/lrr $ROOTACT/lrr/config $LOGDIR $EXCLUDE
fi

# gzip
gzip $tarfile

lrr_UploadToRemote $CRYPTED -u $USER -w "$PASS" -a $HOST -p $PORT -l $tarfile.gz -r $LOGFILE -s $SFTP

exit $?
