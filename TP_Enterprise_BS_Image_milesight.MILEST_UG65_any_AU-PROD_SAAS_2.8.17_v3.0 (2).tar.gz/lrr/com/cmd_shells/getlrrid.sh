#!/bin/sh

# getIniConf()
#
# get configuration from .ini file and print the result
#
# $1: file name
# $2: section name. If present, a '/' in section name must be replaced with '.'
# $3: key name
# return 1 if key found, 0 if not found (to distinguish not set and empty)
#
# usage: res=$(getIniConf file.ini secname key)

INIFILE="$ROOTACT/usr/etc/lrr/_state.ini"

if [ -f ${ROOTACT}/lrr/com/_functions.sh ]
then
	. ${ROOTACT}/lrr/com/_functions.sh
fi

lrrid="Unknown"
[ -f "$INIFILE" ] && lrrid=$(getIniConf "$INIFILE" lrr lrridused)
lrrid=$(echo $lrrid | sed "s/^0x//" | tr '[a-z]' '[A-Z]')

echo	"LRRID=$lrrid"
exit $?
