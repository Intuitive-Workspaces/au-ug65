# Note: some information are not relevant for embedded LRR
SYSTEM="ug6x"
MANUFACTURER="milesight"
FAMILY="ug6x"
MANUFACTURER_OUI="24e124"

ARCH_ARM=y
LITTLE_ENDIAN=y
ARCH="ARCHARM"
OPENWRT=y
LINUX=y
UCLIBC=y
FIRMWARE="openwrt"

SEMTECH_CORECELL=y
SEMTECH_REFDESIGN="corecell"
ARCH_RADIO_VALUE=8
WITH_SPI=y
ARCH_COMM="spi"
SPI_DIR="$ROOTACT/lrr/com/spi/spi/generic_x1"

ROOTACT="/home/actility"
TRACE_BACKUP_DIR="/home/actility/traces"

WITH_GPS=y

TOOLCHAIN_CONFIGURATION_FILE=ug6x/ug6x.mk