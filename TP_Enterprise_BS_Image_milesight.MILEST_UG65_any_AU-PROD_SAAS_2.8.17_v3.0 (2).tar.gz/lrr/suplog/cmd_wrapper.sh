#!/bin/sh

#
# command wrapper for suplog
#

# NO ADDITIONAL OUTPUT: suplog parses command output
# redirect traces to a file

LOG=/tmp/wrapper.log

# log is disabled for production to avoid log file permission issue (suplog switches between root and support)
DEBUG=0

LogInit() {
    if [ "$DEBUG" != 0 ]; then
        rm -f $LOG
        # create it to set correct permissions so nonroot suplog commands can use it
        touch $LOG
        chmod a+rw $LOG
    fi
}

Log() {
    if [ "$DEBUG" != 0 ]; then
        echo "$@" >> $LOG
    fi
}

usage() {
    echo "$0 <cmd> [<arg> ...]"
}

if [ $# -lt 1 ]; then
    usage
    exit 1
fi

LogInit

d=`date +"%d/%m/%Y %H:%M:%S"`
Log "------ $d"
Log "input: $@"

. /var/run/lrrsystem
. ${ROOTACT}/lrr/com/system_setting.sh
. ${ROOTACT}/lrr/com/system_api.sh
. ${ROOTACT}/lrr/envlrr

if [ "$1" = "cmd" ]; then
    # just execute it
    shift
    cmd=$1
    shift
    w=`which $cmd`
    if [ -z "$w" ]; then
        # likely an variable
        eval "cmd=\${$cmd}"
    fi
    Log "cmd: $cmd $@"  
    eval "$cmd $@"
    cr=$?
    Log "status: $cr"
    exit $cr
fi
if [ $1 = "script" ]; then
    # retrieve the path to the script
    shift
    SystemGetFilePath "$ROOTACT/lrr/com/cmd_shells" "$1"
    shift
    Log "script: $sysfilepath $@"
    $sysfilepath "$@"
    cr=$?
    Log "status: $cr"
    exit $cr
fi
exit 1
