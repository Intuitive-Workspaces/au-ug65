#!/bin/sh

# new mechanism: call 
if [ -f /var/run/lrrsystem ]; then
    # new mechanism
    . /var/run/lrrsystem
    export SHELL_MODE=exec
    ${ROOTACT}/lrr/com/shelllrr.sh $*
    # previous scrip should exit, just in case
    exit $?
fi

# keep going with old mechanism

if	[ ! -d "$ROOTACT" ]
then
	echo	"ROOTACT does not exist"
	exit	1
fi

COMMAND="${1}"
shift
if	[ -z "$COMMAND" ]
then
	echo	"no command"
	exit	1
fi

if [ -f ${ROOTACT}/lrr/com/_parameters.sh ]
then
	. ${ROOTACT}/lrr/com/_parameters.sh
fi
if [ -f ${ROOTACT}/lrr/com/_functions.sh ]
then
	. ${ROOTACT}/lrr/com/_functions.sh
fi

lrr_CloseFiles

# old installs do not have SYSTEM in _parameters.sh
if	[ -z "$SYSTEM" ]
then
	SYSTEM=$LRRSYSTEM
fi
export SYSTEM

cd $ROOTACT
DIRCUSTOM=$ROOTACT/usr/etc/lrr/cmd_shells
DIRCOMMAND=$ROOTACT/lrr/com/shells

# command specific to the customer installation
if	[ -x ${DIRCUSTOM}/${COMMAND} ]
then
#	echo "exec ${DIRCUSTOM}/${COMMAND} $*" >> /tmp/lrrshellslog.txt
	exec ${DIRCUSTOM}/${COMMAND} $*
	exit $?
fi

# command specific to the system but in the package
if	[ -x ${DIRCOMMAND}/${SYSTEM}/${COMMAND} ]
then
#	echo "exec ${DIRCOMMAND}/${SYSTEM}/${COMMAND} $*" >> /tmp/lrrshellslog.txt
	exec ${DIRCOMMAND}/${SYSTEM}/${COMMAND} $*
	exit $?
fi

# generic command
#echo "exec ${DIRCOMMAND}/${COMMAND} $*" >> /tmp/lrrshellslog.txt
exec ${DIRCOMMAND}/${COMMAND} $*
exit $?

