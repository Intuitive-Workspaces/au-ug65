#!/bin/sh

# set a parameter in a .ini file
# Use: setiniparam [-r] <inifile> <section> <attribute> <value>
#	<inifile>: ini file to modify/create. If '.ini' extension is not specify it will be added.
#	<section>: section name
#	<attribute>: attribute name
#	<value>: value. It can be several 'words', or empty
#	-r: If empty the param will be removed from ini file"
#	ex: setiniparam lgw gen power 8
#

MOREINI="$ROOTACT/lrr/moreini/moreini.x"
TMPFILE=/tmp/setiniparam_$$
REMALLOWED="0"

if [ "$1" = "-r" ]
then
	# remove key if set to empty
	REMALLOWED="1"
	shift
fi

if [ $# -lt 3 ]
then
	echo "Not enough parameters"
	echo "Use: setiniparam [-r] <inifile> <section> <attribute> <value>"
	echo "<inifile>: ini file to modify/create. If '.ini' extension is not specify it will be added."
	echo "<section>: section name"
	echo "<attribute>: attribute name"
	echo "<value>: value. It can be several 'words', or empty"
	echo "-r: If empty the param will be removed from ini file"
	echo "ex: setiniparam lgw gen power 8"
	exit 1
fi

len=$(expr "$1" : '.*.\.ini$')
if [ $len -gt 0 ]
then
	INIFILE="$1"
else
	INIFILE="$1.ini"
fi

{
echo "[$2]"
echo -n "	$3="
shift 3
if [ $# -gt 1 ]
then
	echo "\"$*\""
elif [ $# -eq 0 -a "$REMALLOWED" = "1" ]
then
	echo "__TOBEREMOVED__"
else
	echo "$*"
fi
} > $TMPFILE

$MOREINI -e -t $ROOTACT/usr/etc/lrr/$INIFILE -a $TMPFILE -y
ret=$?
rm -f $TMPFILE
exit $ret
