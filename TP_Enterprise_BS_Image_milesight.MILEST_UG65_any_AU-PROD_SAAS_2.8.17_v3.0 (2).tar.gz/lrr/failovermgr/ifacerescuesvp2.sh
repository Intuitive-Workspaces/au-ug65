#!/bin/bash

# Copyright (C) Actility, SA. All Rights Reserved.
# DO NOT ALTER OR REMOVE COPYRIGHT NOTICES OR THIS FILE HEADER
#
# This program is free software; you can redistribute it and/or
# modify it under the terms of the GNU General Public License version
# 2 only, as published by the Free Software Foundation.
#
# This program is distributed in the hope that it will be useful, but
# WITHOUT ANY WARRANTY; without even the implied warranty of
# MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the GNU
# General Public License version 2 for more details (a copy is
# included at /legal/license.txt).
#
# You should have received a copy of the GNU General Public License
# version 2 along with this work; if not, write to the Free Software
# Foundation, Inc., 51 Franklin St, Fifth Floor, Boston, MA
# 02110-1301 USA
#
# Please contact Actility, SA.,  4, rue Ampere 22300 LANNION FRANCE
# or visit www.actility.com if you need additional
# information or have any questions.

. $ROOTACT/lrr/com/system_setting.sh
. $ROOTACT/lrr/com/system_api.sh

source ${ROOTACT}/usr/etc/lrr/_parameters.sh

SERVROOTDIR="${ROOTACT}/lrr/failovermgr"

# Load default configuration
source $SERVROOTDIR/default_config

# Load the log function
source $SERVROOTDIR/log_function

# Load the config function
source $SERVROOTDIR/load_config

# Load check interface status function
source $SERVROOTDIR/check_interface_status

# Load restart interface function
SystemGetFilePath "$SERVROOTDIR" "restart_interface"
source $sysfilepath

# Load the ping_routes function
source $SERVROOTDIR/ping_routes

LOGFILE=$ROOTACT/var/log/lrr/ipfailoverrescue2.log
FAILED_RESCUE=0

ipfailover2_periodic_control()
{
	return
}

rescueSvp()
{
	if [ "$RESCUESVP" = "0" ]; then
		return 0
	fi

	if [ "${RESCUEROUTES}" != "" ]; then
		LSTROUTES=${RESCUEROUTES}
	else
		LSTROUTES=${ROUTES}
	fi

	if [ "${RESCUESUCCESSCOUNT}" != "" ]; then
		SUCCESS=${RESCUESUCCESSCOUNT}
	else
		SUCCESS=${SUCCESSCOUNT}
	fi

	ipfailover2_periodic_control $RESCUE

	check $RESCUE
	cnt=$?

	if [ $cnt -ge $RESCUESUCCESSCOUNT ]
	then
		FAILED_RESCUE=0
	else
		FAILED_RESCUE=`expr $FAILED_RESCUE + 1`
		if [ ${FAILED_RESCUE} -ge ${MAX_FAILED_RESCUE} ]
		then
			if restartInterface $RESCUE; then
				FAILED_RESCUE=0
			fi
		fi
	fi

}

Log "#############################################"
Log "### Start $$"
Log "#############################################"

# Load custom
SystemGetFilePath "$SERVROOTDIR" ipfailover_custom.sh
[ -f "$sysfilepath" ] && source $sysfilepath

echo $$ > /var/run/ifacerescuesvp2.pid


PREVRESCUESVP=0

# conf already loaded by ifacefailover2 that launched this script so md5sum already computed
# but conf "broken" when loading default config so need to force reloading
loadConfig "force"

while true
do
	loadConfig

	if [ "$PREVRESCUESVP" = "0" ] && [ "$RESCUESVP" = "1" ]; then
		# If interface is NOT up or no ping success, force interface restart (check return valid ping count, ie 0 is actually failure)
		if ! checkInterfaceStatus $RESCUE || check $RESCUE
		then
			Log "Rescue interface not started. Starting $RESCUE"
			restartInterface $RESCUE
		fi
	fi

	rescueSvp
	sleep ${RESCUECHECKFREQ}
	PREVRESCUESVP=$RESCUESVP
done
