#!/bin/sh

iptables -P INPUT DROP
#ip6tables -P INPUT DROP

#Allow everything on localhost interface
iptables -A INPUT -i lo -j ACCEPT

#Allow All platform support unit for ssh connections
iptables -A INPUT -p tcp --dport 22  -j ACCEPT

# Allow ESTABLISHED/RELATED
iptables -A INPUT -m state --state ESTABLISHED,RELATED -j ACCEPT
