#!/bin/sh

[ "$SYSTEM" = "ciscoms" ]  && echo "ntp_on_host"         && exit 0
[ -f /etc/init.d/settime ] && echo "/etc/init.d/settime" && exit 0 # ufispace
[ -f /etc/init.d/ntpd ]    && echo "/etc/init.d/ntpd"    && exit 0 # tektelic, multitech, kerlink
[ -f /etc/init.d/ntp ]     && echo "/etc/init.d/ntp"     && exit 0 # gemtek && gempiconext
[ -f /etc/init.d/sysntpd ] && echo "/etc/init.d/sysntpd" && exit 0 # milesight ug6x