#!/bin/sh

getFailoverPrincipalInterface() 
{
    itf=$(getIniConf $ROOTACT/usr/etc/lrr/lrr.ini "$SYSTEM/netitf:0" name)
    if [ -z "$itf" ]; then
        itf=$(getIniConf $ROOTACT/lrr/config/lrr.ini "$SYSTEM/netitf:0" name)
    fi
    echo $itf
}

getFailoverRescueInterface()
{
    itf=$(getIniConf $ROOTACT/usr/etc/lrr/lrr.ini "$SYSTEM/netitf:1" name)
    if [ -z "$itf" ]; then
        itf=$(getIniConf $ROOTACT/lrr/config/lrr.ini "$SYSTEM/netitf:1" name)
    fi
    enable=$(getIniConf $ROOTACT/usr/etc/lrr/lrr.ini "$SYSTEM/netitf:1" enable)
    if [ -z "$enable" ]; then
        enable=$(getIniConf $ROOTACT/lrr/config/lrr.ini "$SYSTEM/netitf:1" enable)
    fi
    if [ "$enable" = 1 ]; then
        echo $itf
    else
        echo ""
    fi
}
