#!/bin/sh

. /var/run/lrrsystem

touch $ROOTACT/usr/etc/lrr/execrff_locked
exit $?
