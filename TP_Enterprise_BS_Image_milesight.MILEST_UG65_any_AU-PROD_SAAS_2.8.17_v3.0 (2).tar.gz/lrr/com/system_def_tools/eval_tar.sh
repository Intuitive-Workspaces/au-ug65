#!/bin/sh

if [ -z "$BS_SYSTEM_TMP" ]; then
    BS_SYSTEM_TMP=/tmp
fi

mkdir $BS_SYSTEM_TMP/tartst
mkdir $BS_SYSTEM_TMP/tarout
lst="01.txt 11.txt"
for f in $lst; do
    touch $BS_SYSTEM_TMP/tartst/$f
done

# create the archive
cd $BS_SYSTEM_TMP/tartst; tar cvf $BS_SYSTEM_TMP/tst.tar *

# extract with exclusion
if [ "$1" = "-X" ]; then
    echo "0*.txt" > $BS_SYSTEM_TMP/tstx.lst
    tar xvf $BS_SYSTEM_TMP/tst.tar -X $BS_SYSTEM_TMP/tstx.lst -C $BS_SYSTEM_TMP/tarout
    exit_cr=$?
    rm $BS_SYSTEM_TMP/tstx.lst
else
    tar xvf $BS_SYSTEM_TMP/tst.tar --exclude '0*.txt' -C $BS_SYSTEM_TMP/tarout
    exit_cr=$?
fi

# check that there is only 1 file
if [ $exit_cr = 0 ]; then
    exit_cr=1
    res=`ls -C1 $BS_SYSTEM_TMP/tarout | wc -l`
    if [ $res = 1 ]; then
        exit_cr=0
    fi
fi

# clean the test environment
rm -rf $BS_SYSTEM_TMP/tartst
rm -rf $BS_SYSTEM_TMP/tarout

exit $exit_cr

