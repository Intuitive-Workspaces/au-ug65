#!/bin/sh

. /var/run/lrrsystem

# check if $ROOTACT directory exists
if	[ ! -d "$ROOTACT" ]
then
	echo	"$ROOTACT does not exist"
	exit	1
fi

[ -f "$ROOTACT/lrr/com/_functions.sh" ] && . $ROOTACT/lrr/com/_functions.sh

NFR920=$(getIniConf "$ROOTACT/usr/etc/lrr/lrr.ini" "suplog" "nfr920")
[ -z "$NFR920" ] && NFR920=$(getIniConf "$ROOTACT/lrr/config/lrr.ini" "$SYSTEM/suplog" "nfr920")

if	[ "$NFR920" = "1" ]
then
	echo	"NFR920 activated, 'restoremgr.sh --backup' command used"
	$ROOTACT/lrr/com/cmd_shells/genericmgr.sh restoremgr --backup
	exit $?
fi

# old backup method not supported
exit 1
