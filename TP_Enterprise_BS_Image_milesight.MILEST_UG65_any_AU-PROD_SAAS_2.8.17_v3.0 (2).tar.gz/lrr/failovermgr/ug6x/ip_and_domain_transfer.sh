LOCAL_NAME_ADDR_FILE="/tmp/_DomainNameWithAddress"

name2address() {
    name=$1
    ADDRESS_GET=""
    address=$(ping ${name} -c 1 | sed '1{s/[^(]*(//;s/).*//;q}')
    if [ -n "$address" ]; then
        address_check=$(echo "$address" | grep -oE "([0-9]+\.){3,3}[0-9]{1,3}")
        if [ "$address" != "$address_check" ]; then
            return 1
        fi
        ADDRESS_GET="$address"
    fi
}

#将域名转换到ip地址并保存到本地
name2address_save_file() {
    name=$1
    ADDRESS_GET=""
    address=$(ping ${name} -c 1 | sed '1{s/[^(]*(//;s/).*//;q}')
    if [ -n "$address" ]; then
        address_check=$(echo "$address" | grep -oE "([0-9]+\.){3,3}[0-9]{1,3}")
        if [ "$address" != "$address_check" ]; then
            return 1
        fi
        eval sed -i '/${name}/d' $LOCAL_NAME_ADDR_FILE
        echo "$name $address" >> $LOCAL_NAME_ADDR_FILE
        ADDRESS_GET="$address"
    fi
}

#根据ip地址在本地缓存里面查找域名
address2name() {
    address=$1
    name=$(cat $LOCAL_NAME_ADDR_FILE | grep "$address" | cut -d' ' -f1)
    if [ -n "$name" ]; then
        NAME_GET="$name"
    else
        NAME_GET=""
        return 1
    fi
}

isAddress() {
    address=$1
    address_check=$(echo "$address" | grep -oE "([0-9]+\.){3,3}[0-9]{1,3}")
    if [ "$address" != "$address_check" ]; then
        return 1
    fi
    return 0
}