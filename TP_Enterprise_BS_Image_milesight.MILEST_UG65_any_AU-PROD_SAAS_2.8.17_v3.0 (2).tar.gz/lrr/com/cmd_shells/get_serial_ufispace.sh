#!/bin/sh

nvram get bs_id
