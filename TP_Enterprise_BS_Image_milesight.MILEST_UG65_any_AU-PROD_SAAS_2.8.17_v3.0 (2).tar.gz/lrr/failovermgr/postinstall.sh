#!/bin/sh

if [ -f "/var/run/lrrsystem" ]; then
    . /var/run/lrrsystem
fi
. $ROOTACT/lrr/com/system_setting.sh

[ -f "$ROOTACT/lrr/com/system_api.sh" ] && . $ROOTACT/lrr/com/system_api.sh

if [ -f ${ROOTACT}/lrr/com/_parameters.sh ]
then
	. ${ROOTACT}/lrr/com/_parameters.sh
fi

[ -f $ROOTACT/lrr/com/_functions.sh ] && . $ROOTACT/lrr/com/_functions.sh

# If not active (lrr.ini:[services].ipfailover2=1) just do nothing
# A ipfailover2 restart is required to reread configuration
active=$(getIniConf $ROOTACT/usr/etc/lrr/lrr.ini services ipfailover2)
[ $? = 0 ] && active=$(getIniConf $ROOTACT/lrr/config/lrr.ini services ipfailover2)

if [ "$active" != "1" ]
then
	echo "Service ipfailover2 disabled. If enabled later you must run sysconfiglrr.sh again."
	exit 1
fi

# look for a specific script but avoid this script to call itself (then "noroot")
SystemGetFilePath "$ROOTACT/lrr/failovermgr" "postinstall.sh" "noroot"
if [ ! -z "$sysfilepath" ]; then
    $sysfilepath
fi
