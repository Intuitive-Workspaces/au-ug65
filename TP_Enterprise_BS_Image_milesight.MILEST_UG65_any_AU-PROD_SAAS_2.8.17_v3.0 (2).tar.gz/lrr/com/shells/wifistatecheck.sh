#!/bin/sh
#
#	Identify the state of wifi interface
#
#	states are:
#		- notused
#		- unknown (= interface unknown)
#		- disconnected
#		- connected
#

if [ -f /var/run/lrrsystem ]; then
    . /var/run/lrrsystem
fi

setting=$ROOTACT/lrr/com/system_setting.sh
if [ -f $setting ]; then
    . $setting
fi

file="$ROOTACT/lrr/com/_functions.sh"
[ -f "$file" ] && . $file

WIFICONF="$ROOTACT/lrr/com/shells/$SYSTEM/wificonf.sh"
FAILMGR="$ROOTACT/lrr/failovermgr/failovermgr.x --get"
FAILSTATE="$ROOTACT/usr/data/lrr/_statefailover"
FAILSTATERESCUE="$ROOTACT/usr/data/lrr/_statefailoverrescue"


[ -f "$WIFICONF" ] && . "$WIFICONF"

FREQ="$1"
OUT="$2"

[ -z "$ITNAME" ] && ITNAME="wlan0"

[ -z "$FREQ" ] && FREQ=60

[ -z "$OUT" ] && OUT="/dev/stdout"

CMDFO="$FAILMGR 2>/dev/null"
CMDEXIST="iw dev $ITNAME info"
CMD="iw dev $ITNAME link"

getItNum()
{
	lrrfile="$ROOTACT/usr/etc/lrr/lrr.ini"
	num="0"
	itn=$(getIniConf $lrrfile "$SYSTEM/netitf:$num" name)
#	echo "itn=(getIniConf $lrrfile $SYSTEM/netitf:$num name)"
#	echo "itn=$itn"
	if [ "$itn" != "$ITNAME" ]
	then
		num="1"
		itn=$(getIniConf $lrrfile "$SYSTEM/netitf:$num" name)
#		echo "itn=$itn"
		[ "$itn" != "$ITNAME" ] && num=""
	fi
	echo "$num"
}

# checkInterface
#
# check interface state
#
# return down|noip|connected|disconnected
# down: ifconfig doesn't display the interface
# noip: ifconfig display the interface but itf has no ip address (bad ssid)
# disconnected: itf up with an ip address but itf fails to reach the ping target
# connected: itf up and itf can reach the ping target
checkInterface()
{
	lrrfile="$ROOTACT/usr/etc/lrr/lrr.ini"
	num="$1"

	res=$(ifconfig | grep "^$ITNAME" 2>&1)
	if [ -z "$res" ]
	then
		# itf down
		echo "down"
		return
	fi
	
	itaddr=$(ifconfig $ITNAME | grep "inet addr:" | awk '{ print $2 }' | sed "s/.*://")
	if [ -z "$itaddr" ]
	then
		# itf up but no ip, perhaps bad ssid
		echo "noip"
		return
	fi

	pingaddr=$(getIniConf $lrrfile "netitf:$num" pingaddr)
	if [ -z "$pingaddr" ]
	then
		echo "pingitfail"
		return
	fi

#	echo "ping -I $ITNAME -c 5 -q $pingaddr 2>/dev/null | grep [1-5] packets received"
	pingres=$(ping -I $itaddr -c 5 -q $pingaddr 2>/dev/null | grep "[1-5] packets received")
	if [ ! -z "$pingres" ]
	then
		# at least one packet received, itf ok
		echo "connected"
	else
		# all packets failed
		echo "pingitfail"
	fi
}

echo "$(date '+%Y/%m/%d %H:%M:%S'): $0 started (check every $FREQ s)" >&2
while [ 0 ]
do
	res=$($CMDFO)
	avai=$(echo "$res" | grep "available.*true")
	echo "available:$avai" >&2
	active=$(echo "$res" | grep "active.*true")
	echo "active:$active" >&2
	wifi=$(echo "$res" | grep "name.*\"$ITNAME\"")
	echo "wifi:$wifi" >&2
	itnum=$(getItNum)
	echo "itnum:$itnum" >&2

	# wifi interface used if it's the first one (=netitf:0) or if failover is activated
	# and use "wlan0"
	if [ "$itnum" != "0" ] && [ -z "$itnum" -o -z "$avai" -o -z "$active" -o -z "$wifi" ]
	then
		echo "STATE=notused" > $OUT
	else
		$CMDEXIST >/dev/null 2>&1
		if [ $? -eq 0 ]
		then
			echo "checkInterface:$itnum" >&2
			state=$(checkInterface $itnum)

			echo "STATE=$state" > $OUT

			if [ "$state" = "connected" ]
			then
				res=$($CMD 2>/dev/null | grep "SSID:\|signal:")
				echo "$res" >&2
				ssidrssi=$(echo "$res" | sed "s/.*SSID:[ ]*/SSID=/" | sed "s/.*signal:[ ]*/RSSI=/" | sed "s/[ ]*dBm.*//")
				if [ ! -z "$ssidrssi" ]
				then
					echo "ssid, rssi: '$ssidrssi'" >&2
					echo "$ssidrssi" >> $OUT
				fi
			fi
		else
			echo "STATE=unknown" > $OUT
		fi
	fi
	# usefull for tests
	[ "$FREQ" = "0" ] && break
	sleep $FREQ
done
