#!/bin/sh

INCONSISTENT_CONFIG=2

. $ROOTACT/lrr/com/system_setting.sh
. $ROOTACT/lrr/com/system_api.sh

source ${ROOTACT}/usr/etc/lrr/_parameters.sh
source $ROOTACT/lrr/com/_functions.sh

SERVROOTDIR="${ROOTACT}/lrr/failovermgr"

# Load the log function
source $SERVROOTDIR/log_function

# Load default configuration
source $SERVROOTDIR/default_config

source $SERVROOTDIR/ug6x/ip_and_domain_transfer.sh

LOGFILE=$ROOTACT/var/log/lrr/ipfailover2.log

FORCE_CHECK_FILE=/tmp/force_failover

CHECK_INTERVAL=60

MLOG_FILE=""

MLOG_TEMP_FILE=/tmp/mlog

msg_debug () {
    [ ! -z "$DEBUG" ] && echo "$*"
}

#1:error
#2:warn
#3:info
#4:debug
msg_log () {
    loglvl=$1
    shift
    if [ -f $MLOG_FILE ]; then
        echo "MSG_LOG=${loglvl}${*}" >> $MLOG_FILE
    else
        echo "MSG_LOG=${loglvl}${*}"
    fi
}

# For logging multi lines
msg_log_m () {
    if [ ! -z $1 ]; then
        lvl=$1
    else
        lvl=2
    fi
    if [ -f $MLOG_TEMP_FILE ]; then
        while read logline; do
            msg_log $lvl "$logline"
        done < $MLOG_TEMP_FILE
    fi
}

ini_parser() {
    INI_FILE=$1
    INI_SECTION=$2

    eval `sed -e 's/[[:space:]]*\=[[:space:]]*/=/g' \
        -e 's/;.*$//' \
        -e 's/[[:space:]]*$//' \
        -e 's/^[[:space:]]*//' \
        -e "s/^\(.*\)=\([^\"']*\)$/\1=\"\2\"/" \
    < $INI_FILE \
        | sed -n -e "/^\[$INI_SECTION\]/,/^\s*\[/{/^[^;].*\=.*/p;}"`
}

loadConfig() {

        # check if the user file was changed by using its md5
        md5=$(md5sum $ROOTACT/usr/etc/lrr/ipfailover2.ini | awk '{print $1}')
        if [ "${md5}" = "${savmd5}" ] && [ "$1" != "force" ]; then
            return 0
        fi
        savmd5=${md5}

        if [ -f $ROOTACT/usr/etc/lrr/ipfailover2.ini ] ; then
                ini_parser $ROOTACT/usr/etc/lrr/ipfailover2.ini ipfailover2
                if [ ! -z "$bandwidthconstraint_principal" ]
                then
                        ini_parser $ROOTACT/usr/etc/lrr/ipfailover2.ini "bandwidthconstraint_principal:$bandwidthconstraint_principal"
                fi
                if [ ! -z "$bandwidthconstraint_rescue" ]
                then
                        ini_parser $ROOTACT/usr/etc/lrr/ipfailover2.ini "bandwidthconstraint_rescue:$bandwidthconstraint_rescue"
                fi
        fi

        if [ ! -z "$principal" ] ; then
                PRINCIPAL=$principal
        fi

        if [ ! -z "$rescue" ] ; then
                RESCUE=$rescue
        fi

        if [ ! -z "$rescuesvp" ] ; then
                RESCUESVP=$rescuesvp
        fi

        if [ ! -z "$routes" ] ; then
                ROUTES=$routes
        fi

        if [ ! -z "$checkfreq" ] ; then
                CHECKFREQ=$checkfreq
        fi

        if [ ! -z "$returnfreq" ] ; then
                RETURNFREQ=$returnfreq
        fi

        if [ ! -z "$successcount" ] ; then
                SUCCESSCOUNT=$successcount
        fi

        if [ ! -z "$tmtpingresp" ] ; then
                TMTPINGRESP=$tmtpingresp
        fi

        if [ ! -z "$intervping" ] ; then
                INTERVPING=$intervping
        fi

        if [ ! -z "$intervaddrt" ] ; then
                INTERVADDRT=$intervaddrt
        fi

        if [ ! -z "$countaddrt" ] ; then
                COUNTADDRT=$countaddrt
        fi

        if [ ! -z "$maxfailedprincipal" ] ; then
                MAX_FAILED_PRINCIPAL=$maxfailedprincipal
        fi

        if [ ! -z "$rescueroutes" ] ; then
                RESCUEROUTES=$rescueroutes
        fi

        if [ ! -z "$rescuecheckfreq" ] ; then
                RESCUECHECKFREQ=$rescuecheckfreq
        fi

        if [ ! -z "$rescuesuccesscount" ] ; then
                RESCUESUCCESSCOUNT=$rescuesuccesscount
        fi

        if [ ! -z "$rescuetmtpingresp" ] ; then
                RESCUETMTPINGRESP=$rescuetmtpingresp
        fi

        if [ ! -z "$rescueintervping" ] ; then
                RESCUEINTERVPING=$rescueintervping
        fi

        if [ ! -z "$maxfailedrescue" ] ; then
                MAX_FAILED_RESCUE=$maxfailedrescue
        fi

        if [ ! -z "$removessh" ] ; then
                DELAY_REMOVE_SSH=$removessh
        fi
}

UBUS_GET_TMP=/tmp/_ubus_get_tmp

ubus_call_get () {
    object=$1
    basename=$2
    if [ "$basename""x" = "x" ];then
            ubus call $object get {} > $UBUS_GET_TMP
    else
            ubus call $object get '{"base":"'$basename'"}' > $UBUS_GET_TMP
    fi
}

ubus_call_apply () {
    ubus call yruo_apply apply '{}'
}

CheckOneSLA() {
    idx=$1
    interval_lrr=$2
    timeout_lrr=$3
    consecutive_lrr=$4
    route_one_lrr=$5
    route_sec_lrr=$6

    #change domain name to ip address
    isAddress $route_one_lrr
    if [ "$?" -eq 1 ]; then
        name2address $route_one_lrr
        route_one_lrr="$ADDRESS_GET"
    fi
    isAddress $route_sec_lrr
    if [ "$?" -eq 1 ]; then
        name2address $route_sec_lrr
        route_sec_lrr="$ADDRESS_GET"
    fi

    ubus_call_get yruo_sla
    sla=$(cat $UBUS_GET_TMP  | tr '\n' ' ' |  sed 's/\"type\": \"yruo_sla\"/\n\"type\": \"yruo_sla\"/g' | sed 's/\t//g' | grep "\"sla_idx\": $idx" )
    if [ -z "$sla" ]; then
        #add
        cmd_start_line="ubus call yruo_sla add '{\"base\":\"yruo_sla\",\"index\":\"lrrset\",\"value\":{\"type\":0,\"sla_idx\":$idx,\"packetsize\":56,\"start\":1"
        cmd_end_line="},\"type\":\"yruo_sla\"}'"
        cmd="$cmd_start_line"
        #探测间隔
        if [ -z "$interval_lrr" ]; then
            cmd="$cmd"",\"interval\":30"
        else
            cmd="$cmd"",\"interval\":$interval_lrr"
        fi
        #超时时间
        if [ -z "$timeout_lrr" ]; then
            cmd="$cmd"",\"timeout\":5000"
        else
            cmd="$cmd"",\"timeout\":$timeout_lrr""000"
        fi
        #丢包数
        if [ -z "$consecutive_lrr" ]; then
            cmd="$cmd"",\"consecutive\":5"
        else
            cmd="$cmd"",\"consecutive\":$consecutive_lrr"
        fi
        #ICMP server
        [ -z "$route_one_lrr" ] && route_one_lrr="114.114.114.114"
        [ -z "$route_sec_lrr" ] && route_sec_lrr="8.8.8.8"
        cmd="$cmd"",\"dest\":\"$route_one_lrr\",\"dest_secondary\":\"$route_sec_lrr\""
        cmd="$cmd""$cmd_end_line"
        msg_log 3 "eval $cmd"
        eval $cmd
        ubus_call_apply
    else
        #modify
        index=$(echo $sla | tr ',' '\n' | grep "\"index\"" | awk -F\" '{printf $4}')
        cmd_start_line="ubus call yruo_sla set '{\"base\":\"yruo_sla\",\"index\":\"$index\",\"value\":{"
        cmd_end_line="}}'"
        cmd="$cmd_start_line"
        #get quagga
        interval=$(echo $sla | tr ',' '\n' | grep "\"interval\"" | grep -oE "[0-9]*")
        timeout=$(echo $sla | tr ',' '\n' | grep "\"timeout\"" | grep -oE "[0-9]*")
        consecutive=$(echo $sla | tr ',' '\n' | grep "\"consecutive\"" | grep -oE "[0-9]*")
        pri_addr=$(echo $sla | tr ',' '\n' | grep "\"dest\"" | awk -F\" '{printf $4}')
        sec_addr=$(echo $sla | tr ',' '\n' | grep "\"dest_secondary\"" | awk -F\" '{printf $4}')
        timeout=$(expr $timeout / 1000)

        #check diff
        if [ "$interval" != "$interval_lrr" ]; then
            [ "$cmd" != "$cmd_start_line" ] && cmd="$cmd,"
            cmd="$cmd""\"interval\":$interval_lrr"
        fi
        if [ "$timeout" != "$timeout_lrr" ]; then
            [ "$cmd" != "$cmd_start_line" ] && cmd="$cmd,"
            cmd="$cmd""\"timeout\":$timeout_lrr"
        fi
        if [ "$consecutive" != "$consecutive_lrr" ]; then
            [ "$cmd" != "$cmd_start_line" ] && cmd="$cmd,"
            cmd="$cmd""\"consecutive\":$consecutive_lrr"
        fi
        if [ "$pri_addr" != "$route_one_lrr" ] || [ "$sec_addr" != "$route_sec_lrr" ]; then
            [ "$cmd" != "$cmd_start_line" ] && cmd="$cmd,"
            [ -z "$route_one_lrr" ] && route_one_lrr="114.114.114.114"
            [ -z "$route_sec_lrr" ] && route_sec_lrr="8.8.8.8"
            cmd="$cmd""\"dest\":\"$route_one_lrr\",\"dest_secondary\":\"$route_sec_lrr\""
        fi
        if [ "$cmd" != "$cmd_start_line" ]; then
            cmd="$cmd""$cmd_end_line"
            msg_log 3 "eval $cmd"
            eval $cmd
            ubus_call_apply
        fi
    fi
}

CheckSLA() {
    #check 1 <=> pri
    CheckOneSLA 1 $CHECKFREQ $TMTPINGRESP $MAX_FAILED_PRINCIPAL $ROUTES
    #check 2 <=> rescue
    [ -z "$RESCUEROUTES" ] && RESCUEROUTES=$ROUTES
    CheckOneSLA 2 $RESCUECHECKFREQ $RESCUETMTPINGRESP $MAX_FAILED_RESCUE $RESCUEROUTES
}

CheckOneTrack() {
    idx_lrr=$1
    sla_id_lrr=$2
    ubus_call_get yruo_track
    track=$(cat $UBUS_GET_TMP  | tr '\n' ' ' |  sed 's/\"type\": \"yruo_track\"/\n\"type\": \"yruo_track\"/g' | sed 's/\t//g' | grep "\"track_id\": $idx_lrr" )
    if [ -z "$track" ]; then
        #add
        cmd="ubus call yruo_track add '{\"base\":\"yruo_track\",\"index\":\"lrrset\",\"value\":{\"type\":0,\"sla_id\":$sla_id_lrr,\"track_id\":$idx_lrr,\"nd\":0,\"pd\":1},\"type\":\"yruo_track\"}'"
        msg_log 3 "eval $cmd"
        eval $cmd
        ubus_call_apply
    else
        #modify
        index=$(echo $track | tr ',' '\n' | grep "\"index\"" | awk -F\" '{printf $4}')
        cmd_start_line="ubus call yruo_track set '{\"base\":\"yruo_track\",\"index\":\"$index\",\"value\":{"
        cmd_end_line="}}'"
        cmd="$cmd_start_line"
        #get quagga
        type=$(echo $track | tr ',' '\n' | grep "\"type\"" | tail -n 1 |  grep -oE "[0-9]*")
        sla_id=$(echo $track | tr ',' '\n' | grep "\"sla_id\"" | grep -oE "[0-9]*")
        if [ "$type" != "0" ] || [ "$sla_id" != "$sla_id_lrr" ]; then
            cmd="$cmd""\"track_id\":$idx_lrr,\"type\":0,\"sla_id\":$sla_id_lrr"
            cmd="$cmd""$cmd_end_line"
            msg_log 3 "eval $cmd"
            eval $cmd
            ubus_call_apply
        fi
    fi

}

CheckTrack() {
    CheckOneTrack 1 1
    CheckOneTrack 2 2
}

CheckLinkback() {
    [ "$PRINCIPAL" = "eth0" ] && PRINCIPAL="eth 0"
    [ "$PRINCIPAL" = "cellular0" ] && PRINCIPAL="Cellular 0"
    [ "$RESCUE" = "eth0" ] && RESCUE="eth 0"
    [ "$RESCUE" = "cellular0" ] && RESCUE="Cellular 0"

    ubus_call_get yruo_if_backup
    if_backup=$(cat $UBUS_GET_TMP  | tr '\n' ' ' |  sed 's/\"type\": \"yruo_if_backup\"/\n\"type\": \"yruo_if_backup\"/g' | sed 's/\t//g' | grep "\"type\": \"yruo_if_backup\"" )
    if [ -z "$if_backup" ]; then
        #add
        cmd_start_line="ubus call yruo_if_backup add '{\"base\":\"yruo_if_backup\",\"index\":\"lrrset\",\"value\":{\"startup\":30,\"up\":0,\"down\":0,\"track_id\":1"
        cmd_end_line="},\"type\":\"yruo_if_backup\"}'"
        cmd="$cmd_start_line"
        if [ -n "$RESCUE" ] && [ "$RESCUESVP" =  "1" ]; then
            cmd="$cmd"",\"if_main\":\"$PRINCIPAL\",\"if_backup\":\"$RESCUE\""
            cmd="$cmd""$cmd_end_line"
            msg_log 3 "eval $cmd"
            eval $cmd
            ubus_call_apply
        fi
    else
        #modify
        index=$(echo $if_backup | tr ',' '\n' | grep "\"index\"" | awk -F\" '{printf $4}')
        if [ -n "$RESCUE" ] && [ "$RESCUESVP" =  "1" ]; then
            #compare diff
            if_main=$(echo $if_backup | tr ',' '\n' | sed 's/{/{\n/g' | grep "\"if_main\"" | awk -F\" '{printf $4}')
            if_backup=$(echo $if_backup | tr ',' '\n' | sed 's/{/{\n/g' | grep "\"if_backup\"" | awk -F\" '{printf $4}')
            track_id=$(echo $if_backup | tr ',' '\n' | grep "\"track_id\"" | grep -oE "[0-9]*")
            if [ "$if_main" != "$PRINCIPAL" ] || [ "$if_backup" != "$RESCUE" ] || [ "$track_id" != "$1" ]; then
                cmd="ubus call yruo_if_backup set '{\"base\":\"yruo_if_backup\",\"index\":\"$index\",\"value\":{\"track_id\":1,\"if_main\":\"$PRINCIPAL\",\"if_backup\":\"$RESCUE\"}}'"
                msg_log 3 "eval $cmd"
                eval $cmd
                ubus_call_apply
            fi
        else
            #del
            if_main=$(echo $if_backup | tr ',' '\n' | sed 's/{/{\n/g' | grep "\"if_main\"" | awk -F\" '{printf $4}')
            cmd="ubus call yruo_if_backup delete '{\"base\":\"yruo_if_backup\",\"index\":\"$index\",\"value\":{\"if_main\":\"$if_main\"}}'"
            msg_log 3 "eval $cmd"
            eval $cmd
            ubus_call_apply
        fi
    fi
}

CheckWithQuagga() {
    CheckSLA
    CheckTrack
    CheckLinkback
}

Log "#############################################"
Log "### Start $$"
Log "#############################################"

# LRR do nothing, the work of link backup is handed over to quagga.
while true
do
    active=$(getIniConf $ROOTACT/usr/etc/lrr/lrr.ini services ipfailover2)
    [ $? = 0 ] && active=$(getIniConf $ROOTACT/lrr/config/lrr.ini services ipfailover2)
    if [ "$active" != "1" ]
    then
        Log "ipfailover2 unactivated, doing nothing ..."
        sleep 300
    else
        sleeptime=$CHECK_INTERVAL
        if [ -f "$FORCE_CHECK_FILE" ]; then
            rm -rf $FORCE_CHECK_FILE
        fi
        Log "ipfailover2 activated, doing checnk ..."
        loadConfig
        CheckWithQuagga
        while [ ! -f "$FORCE_CHECK_FILE" ] && [ $sleeptime -gt 0 ]
        do
            sleep 1
            sleeptime=$(expr $sleeptime - 1)
        done
    fi
done