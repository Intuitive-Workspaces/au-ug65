#!/bin/sh
# vim:ft=sh:set noet ts=4 sw=4:
#
#   checkvpn2.sh
#
#   Monitor VPN state:
#   - look for a process named charon. Execute "ipsec start" if missing
#   - check state of the connections. Execute "ipsec stop" + "ipsec start" if state is not ESTABLISHED

exec 2> /dev/null

setting=$ROOTACT/lrr/com/system_setting.sh
if [ -f $setting ]; then
    . $setting
fi

. $ROOTACT/lrr/ipsecmgr/checkvpn2_functions.sh

#
#       MAIN
#

while [ $# -gt 0 ]
do
	case "$1" in
		"-V")
			cat $ROOTACT/lrr/Version
			exit
			;;
		"-v")
			VERBOSE="yes"
			shift
			;;
		"start")
			shift
			;;
		"stop")
			StopVpnProcess
			killall checkvpn2.sh
			shift
			;;
		"routes")
			active=$(getIniConf $ROOTACT/usr/etc/lrr/lrr.ini services checkvpn2)
			[ $? = 0 ] && active=$(getIniConf $ROOTACT/lrr/config/lrr.ini services checkvpn2)
			[ "$active" = "1" ] && [ -f $IPSECCONF ] &&  _updateAddresses
			exit
			;;
		*)
			echo "Unknown option '$1' !"
			Use
			shift
			;;
	esac
done

NOENCODE="$(getIniConf $ROOTACT/usr/etc/lrr/checkvpn2.ini checkvpn2 distarencode)"
verbose=$(getIniConf $ROOTACT/usr/etc/lrr/checkvpn2.ini checkvpn2 tracelvl)
if [ ! -z "$verbose" -a "$verbose" != "0" ]
then
	VERBOSE="yes"
	TRACEFILE="$ROOTACT/var/log/lrr/checkvpn2.log"
	DBG_LOG "################## START $(date) ################"
fi

# If not active (lrr.ini:[services].checkvpn2=1) just do nothing
# A checkvpn2 restart is required to reread configuration
active=$(getIniConf $ROOTACT/usr/etc/lrr/lrr.ini services checkvpn2)
[ $? = 0 ] && active=$(getIniConf $ROOTACT/lrr/config/lrr.ini services checkvpn2)



if [ "$active" != "1" ]
then
	DBG_LOG "checkvpn2 unactivated, doing nothing ..."
	while true
	do
		sleep 3600
	done
	exit 1
fi

updateIpsecIgnoreRoutingTables

StartMonitoring

